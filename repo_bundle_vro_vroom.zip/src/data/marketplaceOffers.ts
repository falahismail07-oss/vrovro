export interface MarketplaceOffer {
  id: string;
  title: string;
  serviceType: string;
  city: string;
  description: string;
  budgetMin: number;
  budgetMax: number;
  date: string;
  status: 'ouverte' | 'réservée' | 'fermée';
  attachments: number;
  images: string[];
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  carBrand?: string;
  carModel?: string;
}

export const marketplaceOffers: MarketplaceOffer[] = [
  {
    id: 'OFF-001',
    title: 'Peinture complète - Renault Clio',
    serviceType: 'Peinture',
    city: 'Casablanca',
    description: 'Peinture totale de la carrosserie, rayures visibles, couleur d\'origine blanche. Photos jointes.',
    budgetMin: 5000,
    budgetMax: 9000,
    date: '2025-06-01',
    status: 'ouverte',
    attachments: 4,
    images: ['/placeholder.svg'],
    clientName: 'Ahmed Benjelloun',
    clientEmail: 'ahmed.b@email.com',
    clientPhone: '+212 6 12 34 56 78',
    carBrand: 'Renault',
    carModel: 'Clio 4'
  },
  {
    id: 'OFF-002',
    title: 'Remplacement embrayage - Peugeot 308',
    serviceType: 'Mécanique',
    city: 'Rabat',
    description: 'Embrayage qui patine. Préférence pour pièce OEM.',
    budgetMin: 2000,
    budgetMax: 3500,
    date: '2025-06-02',
    status: 'ouverte',
    attachments: 2,
    images: ['/placeholder.svg'],
    clientName: 'Fatima Zahra',
    clientEmail: 'fatima.z@email.com',
    clientPhone: '+212 6 23 45 67 89',
    carBrand: 'Peugeot',
    carModel: '308'
  },
  {
    id: 'OFF-003',
    title: 'Remorquage + diagnostic - BMW Série 3',
    serviceType: 'Dépannage',
    city: 'Marrakech',
    description: 'Voiture immobilisée sur route, besoin de remorquage et diagnostic.',
    budgetMin: 500,
    budgetMax: 1500,
    date: '2025-06-03',
    status: 'réservée',
    attachments: 1,
    images: ['/placeholder.svg'],
    clientName: 'Karim El Amrani',
    clientEmail: 'karim.ea@email.com',
    clientPhone: '+212 6 34 56 78 90',
    carBrand: 'BMW',
    carModel: 'Série 3'
  },
  {
    id: 'OFF-004',
    title: 'Climatisation - recharge + fuite',
    serviceType: 'Climatisation',
    city: 'Tanger',
    description: 'Climatisation faible, possible fuite et recharge nécessaire.',
    budgetMin: 400,
    budgetMax: 1200,
    date: '2025-06-04',
    status: 'ouverte',
    attachments: 1,
    images: ['/placeholder.svg'],
    clientName: 'Yasmine Idrissi',
    clientEmail: 'yasmine.i@email.com',
    clientPhone: '+212 6 45 67 89 01'
  },
  {
    id: 'OFF-005',
    title: 'Rénovation jantes + vernis',
    serviceType: 'Carrosserie',
    city: 'Fès',
    description: 'Jantes rayées, besoin de rénovation et vernis protecteur.',
    budgetMin: 300,
    budgetMax: 800,
    date: '2025-06-04',
    status: 'ouverte',
    attachments: 3,
    images: ['/placeholder.svg'],
    clientName: 'Omar Tazi',
    clientEmail: 'omar.t@email.com',
    clientPhone: '+212 6 56 78 90 12'
  },
  {
    id: 'OFF-006',
    title: 'Diagnostic moteur - voyant moteur allumé',
    serviceType: 'Diagnostic',
    city: 'Casablanca',
    description: 'Voyant moteur SRS / check engine, besoin de diagnostic complet.',
    budgetMin: 200,
    budgetMax: 700,
    date: '2025-06-05',
    status: 'ouverte',
    attachments: 0,
    images: ['/placeholder.svg'],
    clientName: 'Rachid Alaoui',
    clientEmail: 'rachid.a@email.com',
    clientPhone: '+212 6 67 89 01 23'
  },
  {
    id: 'OFF-007',
    title: 'Réparation carrosserie suite accident (avant)',
    serviceType: 'Carrosserie',
    city: 'Agadir',
    description: 'Accrochage avant, aile et pare-choc à remplacer/réparer.',
    budgetMin: 2500,
    budgetMax: 6000,
    date: '2025-06-06',
    status: 'ouverte',
    attachments: 5,
    images: ['/placeholder.svg'],
    clientName: 'Nadia Benani',
    clientEmail: 'nadia.b@email.com',
    clientPhone: '+212 6 78 90 12 34',
    carBrand: 'Volkswagen',
    carModel: 'Golf 7'
  },
  {
    id: 'OFF-008',
    title: 'Installation kit audio + caméra de recul',
    serviceType: 'Électronique',
    city: 'Meknès',
    description: 'Installer un kit multimédia avec caméra de recul.',
    budgetMin: 1200,
    budgetMax: 3000,
    date: '2025-06-07',
    status: 'fermée',
    attachments: 2,
    images: ['/placeholder.svg'],
    clientName: 'Mehdi Chraibi',
    clientEmail: 'mehdi.c@email.com',
    clientPhone: '+212 6 89 01 23 45'
  },
  {
    id: 'OFF-009',
    title: 'Changement batterie + test alternateur',
    serviceType: 'Électrique',
    city: 'Tanger',
    description: 'Batterie HS, besoin de remplacement + vérification alternateur.',
    budgetMin: 600,
    budgetMax: 1200,
    date: '2025-06-08',
    status: 'ouverte',
    attachments: 1,
    images: ['/placeholder.svg'],
    clientName: 'Samira Filali',
    clientEmail: 'samira.f@email.com',
    clientPhone: '+212 6 90 12 34 56'
  },
  {
    id: 'OFF-010',
    title: 'Peinture localisée + polissage (retouches)',
    serviceType: 'Peinture',
    city: 'Casablanca',
    description: 'Rayures localisées et besoin de polissage pour finition brillante.',
    budgetMin: 300,
    budgetMax: 900,
    date: '2025-06-09',
    status: 'ouverte',
    attachments: 2,
    images: ['/placeholder.svg'],
    clientName: 'Hamza Berrada',
    clientEmail: 'hamza.b@email.com',
    clientPhone: '+212 6 01 23 45 67'
  }
];

export const serviceTypes = [
  'Tous',
  'Peinture',
  'Mécanique',
  'Carrosserie',
  'Climatisation',
  'Dépannage',
  'Diagnostic',
  'Électronique',
  'Électrique'
];

export const cities = [
  'Toutes',
  'Casablanca',
  'Rabat',
  'Marrakech',
  'Fès',
  'Tanger',
  'Agadir',
  'Meknès'
];
