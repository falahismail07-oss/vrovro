import React, { createContext, useContext, useState, useEffect } from 'react';

interface MarketplaceAuthContextType {
  isAuthenticated: boolean;
  login: (username: string, password: string) => boolean;
  logout: () => void;
}

const MarketplaceAuthContext = createContext<MarketplaceAuthContextType | undefined>(undefined);

export const MarketplaceAuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const authStatus = sessionStorage.getItem('marketplace_auth');
    if (authStatus === 'true') {
      setIsAuthenticated(true);
    }
  }, []);

  const login = (username: string, password: string): boolean => {
    // Identifiants temporaires
    if (username === 'vroGarage' && password === 'vrovro') {
      setIsAuthenticated(true);
      sessionStorage.setItem('marketplace_auth', 'true');
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('marketplace_auth');
  };

  return (
    <MarketplaceAuthContext.Provider value={{ isAuthenticated, login, logout }}>
      {children}
    </MarketplaceAuthContext.Provider>
  );
};

export const useMarketplaceAuth = () => {
  const context = useContext(MarketplaceAuthContext);
  if (!context) {
    throw new Error('useMarketplaceAuth must be used within MarketplaceAuthProvider');
  }
  return context;
};
