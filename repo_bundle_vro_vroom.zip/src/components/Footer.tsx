import { Link } from "react-router-dom";
import { Facebook, Instagram, Linkedin, Mail, MapPin, Phone } from "lucide-react";
import vroLogo from "@/assets/logo-vro.png";
const Footer = () => {
  return <footer className="bg-secondary/50 border-t border-border mt-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <img src={vroLogo} alt="Vro Maroc" className="h-12 w-auto" />
              <span className="text-xl font-bold text-gradient-silver">VRO MAROC</span>
            </div>
            <p className="text-sm text-muted-foreground">Vro Maroc, la plateforme qui connecte automobilistes et garagistes. Trouvez facilement un garage, un constateur ou des accessoires auto, partout au Maroc.</p>
          </div>

          {/* Navigation */}
          <div>
            <h3 className="font-semibold text-primary mb-4">Navigation</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/garages" className="text-sm text-muted-foreground hover:text-primary transition-smooth">
                  Trouver un Garage
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-sm text-muted-foreground hover:text-primary transition-smooth">
                  Services
                </Link>
              </li>
              <li>
                <Link to="/accessoires" className="text-sm text-muted-foreground hover:text-primary transition-smooth">
                  Accessoires
                </Link>
              </li>
              <li>
                <Link to="/garagistes" className="text-sm text-muted-foreground hover:text-primary transition-smooth">
                  Espace Garagistes
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold text-primary mb-4">Contact</h3>
            <ul className="space-y-3">
              <li className="flex items-start space-x-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 mt-0.5 text-primary" />
                <span>Casablanca, Maroc</span>
              </li>
              <li className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Phone className="h-4 w-4 text-primary" />
                <span>+212 5XX-XXXXXX</span>
              </li>
              <li className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Mail className="h-4 w-4 text-primary" />
                <span>contact@vro.ma</span>
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h3 className="font-semibold text-primary mb-4">Suivez-nous</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-muted-foreground hover:text-accent transition-smooth">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-accent transition-smooth">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-accent transition-smooth">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Vro Maroc. Tous droits réservés.</p>
        </div>
      </div>
    </footer>;
};
export default Footer;