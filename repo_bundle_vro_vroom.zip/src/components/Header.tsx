import { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import logoVro from "@/assets/logo-vro.png";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  const mainNavLinks = [
    {
      to: "/garages",
      label: "Garages"
    },
    {
      to: "/services",
      label: "Services"
    },
    {
      to: "/accessoires",
      label: "Accessoires"
    }
  ];

  const servicesLinks = [
    {
      to: "/location-voiture",
      label: "Location de voiture"
    },
    {
      to: "/depannage-remorquage",
      label: "Dépannage & Remorquage"
    },
    {
      to: "/constatateur",
      label: "Constatateur"
    }
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <nav className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2 transition-smooth hover:opacity-80">
            <img src={logoVro} alt="VRO Maroc Logo" className="h-10 w-10" />
            <span className="text-lg md:text-xl font-bold text-gradient-silver">VRO MAROC</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex lg:items-center lg:space-x-4">
            {mainNavLinks.map(link => (
              <NavLink 
                key={link.to} 
                to={link.to} 
                className={({ isActive }) => 
                  `text-sm font-medium transition-smooth hover:text-primary ${isActive ? "text-primary" : "text-muted-foreground"}`
                }
              >
                {link.label}
              </NavLink>
            ))}
            
            <DropdownMenu>
              <DropdownMenuTrigger className="text-sm font-medium text-muted-foreground hover:text-primary transition-smooth outline-none">
                Nos Services ▾
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-background border-border">
                {servicesLinks.map(link => (
                  <DropdownMenuItem key={link.to} asChild>
                    <Link to={link.to} className="cursor-pointer">
                      {link.label}
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <NavLink 
              to="/marketplace-login" 
              className={({ isActive }) => 
                `text-sm font-bold transition-smooth hover:text-primary flex items-center gap-1.5 ${isActive ? "text-primary" : "text-muted-foreground"}`
              }
            >
              Marketplace
              <Badge variant="secondary" className="bg-primary/20 text-primary text-[10px] px-1.5 py-0">★</Badge>
            </NavLink>
          </div>

          {/* CTA Button Desktop */}
          <div className="hidden lg:block">
            <Link to="/constatateur">
              <Button variant="default" className="bg-accent hover:bg-accent/90 shadow-glow text-slate-800">
                Demander un Constatateur
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="lg:hidden text-foreground transition-smooth hover:text-primary">
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden py-4 border-t border-border">
            <div className="flex flex-col space-y-3">
              {mainNavLinks.map(link => (
                <NavLink 
                  key={link.to} 
                  to={link.to} 
                  onClick={() => setIsMenuOpen(false)} 
                  className={({ isActive }) => 
                    `text-sm font-medium py-2 transition-smooth hover:text-primary ${isActive ? "text-primary" : "text-muted-foreground"}`
                  }
                >
                  {link.label}
                </NavLink>
              ))}
              
              <div className="border-t border-border pt-3">
                <p className="text-xs font-semibold text-muted-foreground mb-2">Nos Services</p>
                {servicesLinks.map(link => (
                  <NavLink 
                    key={link.to} 
                    to={link.to} 
                    onClick={() => setIsMenuOpen(false)} 
                    className={({ isActive }) => 
                      `text-sm font-medium py-2 block transition-smooth hover:text-primary ${isActive ? "text-primary" : "text-muted-foreground"}`
                    }
                  >
                    {link.label}
                  </NavLink>
                ))}
              </div>

              <NavLink 
                to="/marketplace-login" 
                onClick={() => setIsMenuOpen(false)} 
                className={({ isActive }) => 
                  `text-sm font-bold py-2 flex items-center gap-1.5 transition-smooth hover:text-primary ${isActive ? "text-primary" : "text-muted-foreground"}`
                }
              >
                Marketplace
                <Badge variant="secondary" className="bg-primary/20 text-primary text-[10px] px-1.5 py-0">★</Badge>
              </NavLink>
              
              <Link to="/constatateur" onClick={() => setIsMenuOpen(false)}>
                <Button variant="default" className="bg-accent hover:bg-accent/90 w-full mt-2">
                  Demander un Constatateur
                </Button>
              </Link>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;
