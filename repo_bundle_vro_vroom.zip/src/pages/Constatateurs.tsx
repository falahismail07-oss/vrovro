import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { AlertCircle, MapPin, Clock, Shield, CheckCircle, Phone } from "lucide-react";

const constatSchema = z.object({
  fullName: z.string().trim().min(2, "Le nom complet est requis").max(100),
  phone: z.string().trim().min(10, "Numéro de téléphone invalide").max(20),
  city: z.string().min(1, "Veuillez sélectionner une ville"),
  address: z.string().trim().min(5, "Adresse complète requise").max(200),
  accidentType: z.string().min(1, "Type d'accident requis"),
  description: z.string().trim().max(500, "Description trop longue").optional(),
  urgency: z.string().min(1, "Niveau d'urgence requis"),
});

type FormData = z.infer<typeof constatSchema>;

const Constatateurs = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedCity, setSelectedCity] = useState("");

  const cities = [
    "Casablanca", "Rabat", "Marrakech", "Fès", "Tanger", "Agadir",
    "Meknès", "Oujda", "Kénitra", "Tétouan", "Safi", "Essaouira",
    "El Jadida", "Nador", "Béni Mellal", "Mohammedia", "Laâyoune",
    "Settat", "Khémisset", "Salé"
  ];

  const accidentTypes = [
    "Collision entre véhicules",
    "Accrochage en stationnement",
    "Accident avec piéton",
    "Sortie de route",
    "Dégâts matériels uniquement",
    "Autre",
  ];

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    reset,
  } = useForm<FormData>({
    resolver: zodResolver(constatSchema),
  });

  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    try {
      // TODO: Implement actual submission logic (e.g., Supabase)
      console.log("Demande constatateur:", data);
      
      toast({
        title: "Constatateur en route !",
        description: "Un constatateur sera sur place dans les 20 minutes. Vous recevrez un SMS de confirmation.",
      });
      
      reset();
      setSelectedCity("");
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Une erreur est survenue. Veuillez réessayer.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const features = [
    {
      icon: Clock,
      title: "Intervention Rapide",
      description: "Constatateur sur place en 20 minutes maximum",
    },
    {
      icon: MapPin,
      title: "Toutes les Villes",
      description: "Service disponible dans toutes les villes du Maroc",
    },
    {
      icon: Shield,
      title: "Professionnel Certifié",
      description: "Constatateurs agréés et formés",
    },
    {
      icon: CheckCircle,
      title: "Dossier Complet",
      description: "Photos, croquis et rapport détaillé",
    },
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/10 mb-4">
            <AlertCircle className="h-8 w-8 text-accent" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gradient-silver">
            Constatateur d'Accident Express
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Un professionnel certifié sur place en 20 minutes pour établir le constat de votre accident
          </p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature, index) => (
            <Card key={index} className="shadow-elegant text-center">
              <CardContent className="pt-6">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-accent/10 mb-4">
                  <feature.icon className="h-6 w-6 text-accent" />
                </div>
                <h3 className="text-lg font-semibold mb-2 text-primary">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Request Form */}
          <Card className="shadow-elegant">
            <CardHeader>
              <CardTitle className="text-2xl text-primary">Demander un Constatateur</CardTitle>
              <CardDescription>
                Remplissez ce formulaire et un constatateur interviendra rapidement
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                {/* Personal Info */}
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Nom Complet *</Label>
                    <Input
                      id="fullName"
                      {...register("fullName")}
                      placeholder="Mohammed Alami"
                    />
                    {errors.fullName && (
                      <p className="text-sm text-destructive">{errors.fullName.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Téléphone *</Label>
                    <Input
                      id="phone"
                      {...register("phone")}
                      placeholder="+212 6XX-XXXXXX"
                    />
                    {errors.phone && (
                      <p className="text-sm text-destructive">{errors.phone.message}</p>
                    )}
                  </div>
                </div>

                {/* Location */}
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="city">Ville *</Label>
                    <Select
                      value={selectedCity}
                      onValueChange={(value) => {
                        setSelectedCity(value);
                        setValue("city", value);
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionnez votre ville" />
                      </SelectTrigger>
                      <SelectContent>
                        {cities.map((city) => (
                          <SelectItem key={city} value={city}>
                            {city}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.city && (
                      <p className="text-sm text-destructive">{errors.city.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address">Adresse Précise de l'Accident *</Label>
                    <Input
                      id="address"
                      {...register("address")}
                      placeholder="Boulevard Mohammed V, près du rond-point"
                    />
                    {errors.address && (
                      <p className="text-sm text-destructive">{errors.address.message}</p>
                    )}
                  </div>
                </div>

                {/* Accident Details */}
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="accidentType">Type d'Accident *</Label>
                    <Select
                      onValueChange={(value) => setValue("accidentType", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionnez le type" />
                      </SelectTrigger>
                      <SelectContent>
                        {accidentTypes.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.accidentType && (
                      <p className="text-sm text-destructive">{errors.accidentType.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="urgency">Niveau d'Urgence *</Label>
                    <Select
                      onValueChange={(value) => setValue("urgency", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Niveau d'urgence" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="high">Élevé - Voie bloquée</SelectItem>
                        <SelectItem value="medium">Moyen - Circulation ralentie</SelectItem>
                        <SelectItem value="low">Faible - Stationnement possible</SelectItem>
                      </SelectContent>
                    </Select>
                    {errors.urgency && (
                      <p className="text-sm text-destructive">{errors.urgency.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Description (optionnel)</Label>
                    <Textarea
                      id="description"
                      {...register("description")}
                      placeholder="Décrivez brièvement l'accident..."
                      rows={3}
                    />
                    {errors.description && (
                      <p className="text-sm text-destructive">{errors.description.message}</p>
                    )}
                  </div>
                </div>

                {/* Submit Button */}
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-accent hover:bg-accent/90 shadow-glow w-full"
                  size="lg"
                >
                  {isSubmitting ? "Envoi en cours..." : "Demander un Constatateur"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Info Panel */}
          <div className="space-y-6">
            <Card className="shadow-elegant">
              <CardHeader>
                <CardTitle className="text-xl text-primary">Comment ça fonctionne ?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center text-accent font-bold">
                    1
                  </div>
                  <div>
                    <h4 className="font-semibold text-primary mb-1">Remplissez le formulaire</h4>
                    <p className="text-sm text-muted-foreground">
                      Indiquez votre localisation et les détails de l'accident
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center text-accent font-bold">
                    2
                  </div>
                  <div>
                    <h4 className="font-semibold text-primary mb-1">Confirmation immédiate</h4>
                    <p className="text-sm text-muted-foreground">
                      Vous recevez un SMS avec les coordonnées du constatateur
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center text-accent font-bold">
                    3
                  </div>
                  <div>
                    <h4 className="font-semibold text-primary mb-1">Intervention sur place</h4>
                    <p className="text-sm text-muted-foreground">
                      Le constatateur arrive en 20 minutes et établit le dossier complet
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-elegant bg-accent/5 border-accent/20">
              <CardHeader>
                <CardTitle className="text-xl text-primary flex items-center">
                  <Phone className="h-5 w-5 mr-2 text-accent" />
                  Urgence 24/7
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Service disponible 24h/24 et 7j/7 dans toutes les villes du Maroc
                </p>
                <div className="text-2xl font-bold text-accent">
                  05XX-XXXXXX
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-elegant">
              <CardHeader>
                <CardTitle className="text-xl text-primary">Ce qui est inclus</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 mr-2 text-accent" />
                    Photos détaillées de l'accident
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 mr-2 text-accent" />
                    Croquis de la scène
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 mr-2 text-accent" />
                    Rapport d'expertise
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 mr-2 text-accent" />
                    Formulaire de constat amiable
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 mr-2 text-accent" />
                    Témoignages si disponibles
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Constatateurs;
