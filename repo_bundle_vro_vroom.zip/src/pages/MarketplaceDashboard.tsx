import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ArrowLeft, FileText, Clock, CheckCircle, XCircle, TrendingUp } from 'lucide-react';

interface SubmittedQuote {
  id: string;
  offerId: string;
  offerTitle: string;
  price: number;
  days: number;
  status: 'en attente' | 'accepté' | 'refusé';
  submittedDate: string;
  clientName: string;
}

const mockSubmittedQuotes: SubmittedQuote[] = [
  {
    id: 'Q-001',
    offerId: 'OFF-001',
    offerTitle: 'Peinture complète - Renault Clio',
    price: 7500,
    days: 4,
    status: 'en attente',
    submittedDate: '2025-06-10',
    clientName: 'Ahmed Benjelloun'
  },
  {
    id: 'Q-002',
    offerId: 'OFF-006',
    offerTitle: 'Diagnostic moteur - voyant moteur allumé',
    price: 450,
    days: 1,
    status: 'accepté',
    submittedDate: '2025-06-09',
    clientName: 'Rachid Alaoui'
  },
  {
    id: 'Q-003',
    offerId: 'OFF-004',
    offerTitle: 'Climatisation - recharge + fuite',
    price: 950,
    days: 2,
    status: 'en attente',
    submittedDate: '2025-06-08',
    clientName: 'Yasmine Idrissi'
  }
];

const MarketplaceDashboard = () => {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'accepté': return <CheckCircle className="w-4 h-4" />;
      case 'refusé': return <XCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'accepté': return 'bg-green-500/10 text-green-600 border-green-500/20';
      case 'refusé': return 'bg-red-500/10 text-red-600 border-red-500/20';
      default: return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
    }
  };

  const totalSubmitted = mockSubmittedQuotes.length;
  const accepted = mockSubmittedQuotes.filter(q => q.status === 'accepté').length;
  const pending = mockSubmittedQuotes.filter(q => q.status === 'en attente').length;
  const totalRevenue = mockSubmittedQuotes
    .filter(q => q.status === 'accepté')
    .reduce((sum, q) => sum + q.price, 0);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <Link to="/marketplace">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour à la marketplace
          </Button>
        </Link>

        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Mon tableau de bord</h1>
          <p className="text-muted-foreground">
            Gérez vos devis soumis et suivez vos performances
          </p>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Devis soumis</p>
                  <p className="text-3xl font-bold">{totalSubmitted}</p>
                </div>
                <FileText className="w-8 h-8 text-primary/60" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">En attente</p>
                  <p className="text-3xl font-bold">{pending}</p>
                </div>
                <Clock className="w-8 h-8 text-amber-500/60" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Acceptés</p>
                  <p className="text-3xl font-bold">{accepted}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-500/60" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Revenus générés</p>
                  <p className="text-2xl font-bold">{totalRevenue.toLocaleString()} DH</p>
                </div>
                <TrendingUp className="w-8 h-8 text-blue-500/60" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Submitted Quotes Table */}
        <Card>
          <CardHeader>
            <CardTitle>Mes devis soumis</CardTitle>
            <CardDescription>
              Historique de tous vos devis et leur statut actuel
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Réf. Devis</TableHead>
                  <TableHead>Offre</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Prix proposé</TableHead>
                  <TableHead>Délai</TableHead>
                  <TableHead>Date soumission</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockSubmittedQuotes.map(quote => (
                  <TableRow key={quote.id}>
                    <TableCell className="font-medium">{quote.id}</TableCell>
                    <TableCell>
                      <div className="max-w-xs">
                        <p className="font-medium line-clamp-1">{quote.offerTitle}</p>
                        <p className="text-xs text-muted-foreground">Réf: {quote.offerId}</p>
                      </div>
                    </TableCell>
                    <TableCell>{quote.clientName}</TableCell>
                    <TableCell className="font-semibold">{quote.price.toLocaleString()} DH</TableCell>
                    <TableCell>{quote.days} jour{quote.days > 1 ? 's' : ''}</TableCell>
                    <TableCell>{new Date(quote.submittedDate).toLocaleDateString('fr-FR')}</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(quote.status)} variant="outline">
                        <span className="flex items-center gap-1">
                          {getStatusIcon(quote.status)}
                          {quote.status}
                        </span>
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Link to={`/marketplace/offer/${quote.offerId}`}>
                        <Button variant="ghost" size="sm">
                          Voir offre
                        </Button>
                      </Link>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {mockSubmittedQuotes.length === 0 && (
              <div className="text-center py-12 text-muted-foreground">
                <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Vous n'avez pas encore soumis de devis</p>
                <Link to="/marketplace">
                  <Button variant="outline" className="mt-4">
                    Parcourir les offres
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default MarketplaceDashboard;
