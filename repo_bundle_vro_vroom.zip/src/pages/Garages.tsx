import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MapPin, Star, Phone, Clock } from "lucide-react";
import garage1 from "@/assets/garage-1.jpg";
import garage2 from "@/assets/garage-2.jpg";
import garage3 from "@/assets/garage-3.jpg";
import garage4 from "@/assets/garage-4.jpg";

const Garages = () => {
  const navigate = useNavigate();
  const [selectedCity, setSelectedCity] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const garages = [
    {
      id: 1,
      name: "Garage Premium Auto",
      city: "Casablanca",
      services: ["Mécanique", "Peinture", "Diagnostic"],
      rating: 4.8,
      price: "À partir de 300 DH",
      phone: "+212 522-XXXXXX",
      hours: "Lun-Sam: 8h-18h",
      image: garage1,
    },
    {
      id: 2,
      name: "Pro Mécanique",
      city: "Rabat",
      services: ["Mécanique", "Vidange", "Freinage"],
      rating: 4.6,
      price: "À partir de 250 DH",
      phone: "+212 537-XXXXXX",
      hours: "Lun-Ven: 8h-17h",
      image: garage2,
    },
    {
      id: 3,
      name: "Auto Excellence",
      city: "Marrakech",
      services: ["Peinture", "Carrosserie", "Lavage"],
      rating: 4.9,
      price: "À partir de 400 DH",
      phone: "+212 524-XXXXXX",
      hours: "Lun-Sam: 9h-19h",
      image: garage3,
    },
    {
      id: 4,
      name: "Speed Garage",
      city: "Tanger",
      services: ["Mécanique", "Diagnostic", "Climatisation"],
      rating: 4.7,
      price: "À partir de 280 DH",
      phone: "+212 539-XXXXXX",
      hours: "Lun-Sam: 8h-18h",
      image: garage4,
    },
    {
      id: 5,
      name: "Atlas Motors",
      city: "Fès",
      services: ["Mécanique", "Électricité", "Révision"],
      rating: 4.5,
      price: "À partir de 260 DH",
      phone: "+212 535-XXXXXX",
      hours: "Lun-Sam: 8h-18h",
      image: garage1,
    },
    {
      id: 6,
      name: "Garage Moderne",
      city: "Agadir",
      services: ["Diagnostic", "Vidange", "Climatisation"],
      rating: 4.6,
      price: "À partir de 270 DH",
      phone: "+212 528-XXXXXX",
      hours: "Lun-Sam: 8h-19h",
      image: garage2,
    },
    {
      id: 7,
      name: "Euro Car Service",
      city: "Casablanca",
      services: ["Mécanique", "Peinture", "Carrosserie"],
      rating: 4.9,
      price: "À partir de 450 DH",
      phone: "+212 522-XXXXXX",
      hours: "Lun-Ven: 9h-18h",
      image: garage3,
    },
    {
      id: 8,
      name: "Garage Al Amal",
      city: "Oujda",
      services: ["Mécanique", "Freinage", "Pneus"],
      rating: 4.4,
      price: "À partir de 240 DH",
      phone: "+212 536-XXXXXX",
      hours: "Lun-Sam: 8h-17h",
      image: garage4,
    },
    {
      id: 9,
      name: "Meknes Auto Center",
      city: "Meknès",
      services: ["Vidange", "Diagnostic", "Géométrie"],
      rating: 4.7,
      price: "À partir de 265 DH",
      phone: "+212 535-XXXXXX",
      hours: "Lun-Sam: 8h-18h",
      image: garage1,
    },
    {
      id: 10,
      name: "Garage Atlantique",
      city: "El Jadida",
      services: ["Mécanique", "Lavage", "Entretien"],
      rating: 4.5,
      price: "À partir de 230 DH",
      phone: "+212 523-XXXXXX",
      hours: "Lun-Sam: 8h-18h",
      image: garage2,
    },
    {
      id: 11,
      name: "Tetouan Motors",
      city: "Tétouan",
      services: ["Peinture", "Carrosserie", "Diagnostic"],
      rating: 4.6,
      price: "À partir de 290 DH",
      phone: "+212 539-XXXXXX",
      hours: "Lun-Ven: 8h-17h",
      image: garage3,
    },
    {
      id: 12,
      name: "Garage Sahara",
      city: "Laâyoune",
      services: ["Mécanique", "4x4", "Dépannage"],
      rating: 4.8,
      price: "À partir de 320 DH",
      phone: "+212 528-XXXXXX",
      hours: "Lun-Sam: 8h-19h",
      image: garage4,
    },
    {
      id: 13,
      name: "Mohammedia Auto",
      city: "Mohammedia",
      services: ["Vidange", "Freinage", "Climatisation"],
      rating: 4.4,
      price: "À partir de 245 DH",
      phone: "+212 523-XXXXXX",
      hours: "Lun-Sam: 8h-18h",
      image: garage1,
    },
    {
      id: 14,
      name: "Garage Nador",
      city: "Nador",
      services: ["Mécanique", "Peinture", "Électricité"],
      rating: 4.5,
      price: "À partir de 255 DH",
      phone: "+212 536-XXXXXX",
      hours: "Lun-Sam: 8h-18h",
      image: garage2,
    },
    {
      id: 15,
      name: "Kénitra Car Care",
      city: "Kénitra",
      services: ["Diagnostic", "Révision", "Entretien"],
      rating: 4.7,
      price: "À partir de 275 DH",
      phone: "+212 537-XXXXXX",
      hours: "Lun-Sam: 8h-18h",
      image: garage3,
    },
    {
      id: 16,
      name: "Garage Royal",
      city: "Rabat",
      services: ["Mécanique", "Peinture", "Carrosserie"],
      rating: 4.9,
      price: "À partir de 380 DH",
      phone: "+212 537-XXXXXX",
      hours: "Lun-Sam: 9h-19h",
      image: garage4,
    },
    {
      id: 17,
      name: "Safi Auto Service",
      city: "Safi",
      services: ["Vidange", "Mécanique", "Freinage"],
      rating: 4.3,
      price: "À partir de 235 DH",
      phone: "+212 524-XXXXXX",
      hours: "Lun-Sam: 8h-17h",
      image: garage1,
    },
    {
      id: 18,
      name: "Garage Essaouira",
      city: "Essaouira",
      services: ["Mécanique", "Lavage", "Diagnostic"],
      rating: 4.6,
      price: "À partir de 260 DH",
      phone: "+212 524-XXXXXX",
      hours: "Lun-Sam: 8h-18h",
      image: garage2,
    },
    {
      id: 19,
      name: "Beni Mellal Motors",
      city: "Beni Mellal",
      services: ["Mécanique", "Vidange", "Pneus"],
      rating: 4.5,
      price: "À partir de 250 DH",
      phone: "+212 523-XXXXXX",
      hours: "Lun-Sam: 8h-18h",
      image: garage3,
    },
    {
      id: 20,
      name: "Garage Settat",
      city: "Settat",
      services: ["Diagnostic", "Électricité", "Freinage"],
      rating: 4.4,
      price: "À partir de 240 DH",
      phone: "+212 523-XXXXXX",
      hours: "Lun-Sam: 8h-18h",
      image: garage4,
    },
  ];

  const cities = ["all", "Casablanca", "Rabat", "Marrakech", "Tanger", "Fès", "Agadir", "Oujda", "Meknès", "El Jadida", "Tétouan", "Laâyoune", "Mohammedia", "Nador", "Kénitra", "Safi", "Essaouira", "Beni Mellal", "Settat"];

  const filteredGarages = garages.filter((garage) => {
    const matchesCity = selectedCity === "all" || garage.city === selectedCity;
    const matchesSearch = garage.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         garage.services.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCity && matchesSearch;
  });

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gradient-silver">
            Trouvez Votre Garage
          </h1>
          <p className="text-lg text-muted-foreground">
            Comparez les services et réservez en ligne
          </p>
        </div>

        {/* Filters */}
        <div className="mb-8 flex flex-col md:flex-row gap-4">
          <Input
            placeholder="Rechercher un garage ou service..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1"
          />
          <Select value={selectedCity} onValueChange={setSelectedCity}>
            <SelectTrigger className="w-full md:w-[200px]">
              <SelectValue placeholder="Ville" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Toutes les villes</SelectItem>
              {cities.slice(1).map((city) => (
                <SelectItem key={city} value={city}>
                  {city}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Map Placeholder */}
        <div className="mb-8 h-64 bg-secondary/30 rounded-lg border border-border flex items-center justify-center">
          <div className="text-center">
            <MapPin className="h-12 w-12 mx-auto mb-2 text-primary" />
            <p className="text-muted-foreground">Carte interactive des garages</p>
          </div>
        </div>

        {/* Garages List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredGarages.map((garage) => (
            <Card key={garage.id} className="shadow-elegant hover:shadow-glow transition-smooth overflow-hidden">
              <div className="h-48 overflow-hidden">
                <img 
                  src={garage.image} 
                  alt={garage.name}
                  className="w-full h-full object-cover hover:scale-110 transition-smooth"
                />
              </div>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-primary">{garage.name}</CardTitle>
                  <div className="flex items-center space-x-1 text-accent">
                    <Star className="h-4 w-4 fill-current" />
                    <span className="font-semibold">{garage.rating}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center text-sm text-muted-foreground">
                  <MapPin className="h-4 w-4 mr-2 text-primary" />
                  {garage.city}
                </div>
                
                <div className="flex flex-wrap gap-2">
                  {garage.services.map((service, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-secondary text-secondary-foreground text-xs rounded-full"
                    >
                      {service}
                    </span>
                  ))}
                </div>

                <div className="flex items-center text-sm text-muted-foreground">
                  <Phone className="h-4 w-4 mr-2 text-primary" />
                  {garage.phone}
                </div>

                <div className="flex items-center text-sm text-muted-foreground">
                  <Clock className="h-4 w-4 mr-2 text-primary" />
                  {garage.hours}
                </div>

                <div className="pt-4 border-t border-border flex justify-between items-center">
                  <span className="text-lg font-semibold text-primary">{garage.price}</span>
                  <Button 
                    className="bg-accent hover:bg-accent/90 shadow-glow"
                    onClick={() => navigate(`/reservation?garage=${encodeURIComponent(garage.name)}&city=${encodeURIComponent(garage.city)}`)}
                  >
                    Réserver
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredGarages.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg">Aucun garage trouvé avec ces critères</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Garages;
