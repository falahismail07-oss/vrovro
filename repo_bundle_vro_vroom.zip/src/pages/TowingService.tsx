import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Truck, Wrench, Phone, MapPin, Clock, Shield, Star, CheckCircle } from "lucide-react";

const TowingService = () => {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    location: "",
    issueType: "",
    message: "",
  });

  const services = [
    {
      icon: Truck,
      title: "Remorquage de véhicules légers et utilitaires",
      description: "Transport sécurisé de votre véhicule vers le garage de votre choix"
    },
    {
      icon: Wrench,
      title: "Dépannage sur place",
      description: "Batterie, pneu, carburant, démarrage - nous intervenons rapidement"
    },
    {
      icon: MapPin,
      title: "Assistance autoroutière 24h/24",
      description: "Intervention rapide sur toutes les autoroutes du Maroc"
    },
    {
      icon: Shield,
      title: "Transport de voitures de luxe",
      description: "Plateau sécurisé pour véhicules haut de gamme"
    },
    {
      icon: Phone,
      title: "Assistance en cas d'accident",
      description: "Support complet et accompagnement administratif"
    },
  ];

  const whyChoose = [
    {
      icon: Clock,
      title: "Intervention rapide",
      description: "Moins de 30 minutes dans les grandes villes"
    },
    {
      icon: MapPin,
      title: "Réseau national",
      description: "Dépanneurs agréés partout au Maroc"
    },
    {
      icon: CheckCircle,
      title: "Tarifs transparents",
      description: "Paiement en ligne sécurisé"
    },
    {
      icon: Shield,
      title: "Service 24h/24, 7j/7",
      description: "Toujours disponibles pour vous aider"
    },
  ];

  const cities = [
    "Casablanca", "Rabat", "Marrakech", "Tanger", "Agadir", 
    "Fès", "Meknès", "Oujda", "Tétouan", "Kenitra"
  ];

  const issueTypes = [
    "Panne mécanique",
    "Crevaison",
    "Batterie déchargée",
    "Panne d'essence",
    "Accident",
    "Autre"
  ];

  const testimonials = [
    {
      name: "Karim M.",
      city: "Casablanca",
      rating: 5,
      text: "Remorqué en 20 minutes à Casablanca ! Excellent service, équipe professionnelle."
    },
    {
      name: "Sarah L.",
      city: "Marrakech",
      rating: 5,
      text: "Service impeccable, même de nuit. Ils ont sauvé mes vacances !"
    },
    {
      name: "Omar B.",
      city: "Rabat",
      rating: 5,
      text: "Très professionnel, tarifs honnêtes. Je recommande vivement Vro !"
    },
  ];

  const faqs = [
    {
      question: "Quels sont vos tarifs ?",
      answer: "Nos tarifs varient selon la distance et le type d'intervention. En moyenne, un remorquage en ville coûte entre 300 et 600 DH. Demandez un devis gratuit en nous contactant."
    },
    {
      question: "Puis-je payer sur place ?",
      answer: "Oui, nous acceptons le paiement en espèces, par carte bancaire et en ligne via notre plateforme sécurisée."
    },
    {
      question: "Intervenez-vous sur autoroute ?",
      answer: "Oui, nous intervenons 24h/24 sur toutes les autoroutes du Maroc avec un délai d'intervention moyen de 30-45 minutes."
    },
    {
      question: "Proposez-vous le transport longue distance ?",
      answer: "Oui, nous assurons le remorquage longue distance partout au Maroc. Contactez-nous pour un devis personnalisé."
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    // Here you would typically send the data to a backend or WhatsApp
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[500px] flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ 
            backgroundImage: "url('https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=1600')",
            filter: "brightness(0.4)"
          }}
        />
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 text-white">
            🚨 Dépannage & Remorquage 24h/24
          </h1>
          <p className="text-xl md:text-2xl text-white mb-2">
            Où que vous soyez, Vro intervient !
          </p>
          <p className="text-lg text-white/90 mb-8">
            Panne, crevaison, accident ? Nos équipes interviennent rapidement partout au Maroc.
          </p>
          <Button 
            size="lg" 
            className="bg-accent hover:bg-accent/90 text-slate-800 shadow-glow text-lg px-8 py-6"
            onClick={() => document.getElementById('intervention-form')?.scrollIntoView({ behavior: 'smooth' })}
          >
            Demander une intervention immédiate
          </Button>
        </div>
      </section>

      <div className="container mx-auto px-4 py-12">
        {/* Services Section */}
        <section className="mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Nos services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, index) => (
              <Card key={index} className="hover-scale shadow-elegant">
                <CardHeader>
                  <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center mb-4">
                    <service.icon className="w-8 h-8 text-accent" />
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Why Choose Vro */}
        <section className="mb-16 bg-muted/50 rounded-lg p-8">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Pourquoi choisir Vro ?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {whyChoose.map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                  <item.icon className="w-8 h-8 text-slate-800" />
                </div>
                <h3 className="font-bold text-lg mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Intervention Form */}
        <section id="intervention-form" className="mb-16">
          <Card className="max-w-2xl mx-auto shadow-elegant">
            <CardHeader>
              <CardTitle className="text-2xl text-center">Demande d'intervention</CardTitle>
              <p className="text-center text-muted-foreground">
                Remplissez le formulaire ci-dessous, nous vous recontactons immédiatement
              </p>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="name">Nom / Prénom *</Label>
                  <Input
                    id="name"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>

                <div>
                  <Label htmlFor="phone">Numéro de téléphone *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>

                <div>
                  <Label htmlFor="location">Localisation / Adresse *</Label>
                  <Input
                    id="location"
                    required
                    placeholder="Ex: Autoroute Casablanca-Rabat, km 23"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  />
                </div>

                <div>
                  <Label htmlFor="issueType">Type de panne *</Label>
                  <Select
                    value={formData.issueType}
                    onValueChange={(value) => setFormData({ ...formData, issueType: value })}
                  >
                    <SelectTrigger id="issueType">
                      <SelectValue placeholder="Sélectionnez le type de panne" />
                    </SelectTrigger>
                    <SelectContent>
                      {issueTypes.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="message">Description du problème</Label>
                  <Textarea
                    id="message"
                    placeholder="Décrivez brièvement votre situation..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    rows={4}
                  />
                </div>

                <div>
                  <Label htmlFor="photo">Photo du véhicule (optionnel)</Label>
                  <Input
                    id="photo"
                    type="file"
                    accept="image/*"
                  />
                </div>

                <Button type="submit" className="w-full bg-accent hover:bg-accent/90 shadow-glow text-slate-800 text-lg py-6">
                  Envoyer ma demande
                </Button>

                <p className="text-sm text-center text-muted-foreground">
                  Un conseiller vous contactera dans les 5 minutes
                </p>
              </form>
            </CardContent>
          </Card>
        </section>

        {/* Zones Covered */}
        <section className="mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-8">Zones couvertes</h2>
          <Card className="shadow-elegant">
            <CardContent className="p-6">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                {cities.map((city) => (
                  <div
                    key={city}
                    className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg hover-scale cursor-pointer"
                  >
                    <MapPin className="w-5 h-5 text-accent" />
                    <span className="font-medium">{city}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Testimonials */}
        <section className="mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Témoignages clients</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="shadow-elegant">
                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <CardTitle className="text-lg">{testimonial.name}</CardTitle>
                      <p className="text-sm text-muted-foreground">{testimonial.city}</p>
                    </div>
                    <div className="flex gap-1">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-accent text-accent" />
                      ))}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground italic">"{testimonial.text}"</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* FAQ */}
        <section className="mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Questions fréquentes</h2>
          <Card className="max-w-3xl mx-auto shadow-elegant">
            <CardContent className="p-6">
              <Accordion type="single" collapsible className="w-full">
                {faqs.map((faq, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="text-left font-semibold">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </section>

        {/* CTA Section */}
        <section className="bg-accent/10 rounded-lg p-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Besoin d'assistance immédiate ?</h2>
          <p className="text-lg text-muted-foreground mb-6">
            Contactez-nous maintenant, nos équipes sont disponibles 24h/24
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button size="lg" className="bg-accent hover:bg-accent/90 text-slate-800 shadow-glow">
              <Phone className="w-5 h-5 mr-2" />
              Appeler maintenant
            </Button>
            <Button size="lg" variant="outline" className="shadow-glow">
              WhatsApp
            </Button>
          </div>
          <p className="mt-4 text-sm text-muted-foreground">
            📞 Urgence: +212 6 XX XX XX XX
          </p>
        </section>
      </div>
    </div>
  );
};

export default TowingService;