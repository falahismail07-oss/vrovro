import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Wrench, Paintbrush, Droplets, Zap, Wind, Car, Settings, ShieldCheck,
  Gauge, Battery, Sparkles, Truck, CircleDot, AlertCircle, Disc, Package, Palette
} from "lucide-react";
import { Link } from "react-router-dom";

const Services = () => {
  const services = [
    {
      icon: Wrench,
      title: "Mécanique Générale",
      description: "Réparation et entretien complet de votre véhicule",
      details: [
        "Révision complète",
        "Réparation moteur",
        "Système de freinage",
        "Embrayage et transmission",
      ],
      price: "À partir de 300 DH",
    },
    {
      icon: Paintbrush,
      title: "Peinture & Carrosserie",
      description: "Remise en état et customisation de votre carrosserie",
      details: [
        "Peinture complète",
        "Retouches localisées",
        "Débosselage sans peinture",
        "Polissage et lustrage",
      ],
      price: "À partir de 500 DH",
    },
    {
      icon: Droplets,
      title: "Vidange & Entretien",
      description: "Maintenance régulière pour la longévité de votre moteur",
      details: [
        "Vidange huile moteur",
        "Changement filtres",
        "Contrôle niveaux",
        "Graissage",
      ],
      price: "À partir de 200 DH",
    },
    {
      icon: Zap,
      title: "Diagnostic Électronique",
      description: "Analyse complète des systèmes électroniques",
      details: [
        "Diagnostic OBD",
        "Lecture codes erreur",
        "Réinitialisation voyants",
        "Reprogrammation ECU",
      ],
      price: "À partir de 150 DH",
    },
    {
      icon: Wind,
      title: "Climatisation",
      description: "Entretien et recharge de votre système de climatisation",
      details: [
        "Recharge gaz",
        "Désinfection circuit",
        "Contrôle compresseur",
        "Changement filtre habitacle",
      ],
      price: "À partir de 250 DH",
    },
    {
      icon: Car,
      title: "Lavage Premium",
      description: "Nettoyage professionnel intérieur et extérieur",
      details: [
        "Lavage extérieur complet",
        "Nettoyage intérieur",
        "Polish et protection",
        "Traitement céramique",
      ],
      price: "À partir de 100 DH",
    },
    {
      icon: Settings,
      title: "Géométrie & Parallélisme",
      description: "Alignement précis des roues pour une conduite optimale",
      details: [
        "Géométrie 4 roues",
        "Équilibrage",
        "Réglage parallélisme",
        "Contrôle suspension",
      ],
      price: "À partir de 180 DH",
    },
    {
      icon: ShieldCheck,
      title: "Contrôle Technique",
      description: "Préparation et accompagnement pour le contrôle technique",
      details: [
        "Pré-contrôle complet",
        "Réparations conformité",
        "Accompagnement centre agréé",
        "Suivi dossier",
      ],
      price: "À partir de 350 DH",
    },
    {
      icon: Gauge,
      title: "Révision Complète",
      description: "Check-up intégral de votre véhicule",
      details: [
        "Contrôle tous niveaux",
        "Vérification freins",
        "Test batterie",
        "Contrôle éclairage",
      ],
      price: "À partir de 400 DH",
    },
    {
      icon: Battery,
      title: "Électricité Auto",
      description: "Diagnostic et réparation système électrique",
      details: [
        "Alternateur",
        "Démarreur",
        "Faisceau électrique",
        "Installation accessoires",
      ],
      price: "À partir de 300 DH",
    },
    {
      icon: Sparkles,
      title: "Détailing Premium",
      description: "Nettoyage professionnel de luxe",
      details: [
        "Polissage multi-étapes",
        "Traitement cuir",
        "Céramique protection",
        "Nettoyage moteur",
      ],
      price: "À partir de 800 DH",
    },
    {
      icon: Truck,
      title: "Entretien Poids Lourds",
      description: "Services pour véhicules utilitaires",
      details: [
        "Révision camions",
        "Maintenance flottes",
        "Réparation carrosserie",
        "Pneumatiques renforcés",
      ],
      price: "À partir de 600 DH",
    },
    {
      icon: CircleDot,
      title: "Montage Pneus",
      description: "Installation et équilibrage pneumatiques",
      details: [
        "Montage 4 pneus",
        "Équilibrage précis",
        "Contrôle pression",
        "Valve neuve offerte",
      ],
      price: "À partir de 120 DH",
    },
    {
      icon: AlertCircle,
      title: "Dépannage Express",
      description: "Intervention rapide en cas de panne",
      details: [
        "Diagnostic urgent",
        "Réparation sur place",
        "Remorquage disponible",
        "Service 7j/7",
      ],
      price: "À partir de 200 DH",
    },
    {
      icon: Disc,
      title: "Freinage Complet",
      description: "Révision et remplacement système de freinage",
      details: [
        "Plaquettes avant/arrière",
        "Disques de frein",
        "Liquide de frein",
        "Test sécurité",
      ],
      price: "À partir de 450 DH",
    },
    {
      icon: Package,
      title: "Forfait Entretien",
      description: "Pack maintenance tout compris",
      details: [
        "Vidange complète",
        "Filtres neufs",
        "Points de contrôle",
        "Lavage offert",
      ],
      price: "À partir de 380 DH",
    },
    {
      icon: Palette,
      title: "Habillage Voiture",
      description: "Personnalisation complète intérieur et extérieur",
      details: [
        "Covering vinyle extérieur",
        "Habillage tableau de bord",
        "Revêtement sièges cuir/tissu",
        "Customisation volant et pommeau",
      ],
      price: "À partir de 1500 DH",
    },
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gradient-silver">
            Nos Services Automobiles
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Une gamme complète de services pour l'entretien et la réparation de votre véhicule
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6 mb-12">
          {services.map((service, index) => (
            <Card key={index} className="shadow-elegant hover:shadow-glow transition-smooth group">
              <CardHeader className="p-4">
                <div className="inline-flex items-center justify-center w-16 h-16 md:w-20 md:h-20 rounded-full bg-accent/10 mb-3 mx-auto group-hover:bg-accent/20 transition-smooth">
                  <service.icon className="h-8 w-8 md:h-10 md:w-10 text-accent" />
                </div>
                <CardTitle className="text-base md:text-lg text-foreground text-center line-clamp-2 min-h-[2.5rem]">
                  {service.title}
                </CardTitle>
                <CardDescription className="text-xs md:text-sm text-center line-clamp-2">
                  {service.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3 px-4 pb-4">
                <ul className="space-y-1.5">
                  {service.details.slice(0, 3).map((detail, idx) => (
                    <li key={idx} className="text-xs md:text-sm text-muted-foreground flex items-start">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent mr-2 mt-1.5 flex-shrink-0" />
                      <span className="line-clamp-1">{detail}</span>
                    </li>
                  ))}
                  {service.details.length > 3 && (
                    <li className="text-xs text-accent">+{service.details.length - 3} autres</li>
                  )}
                </ul>
                <div className="pt-3 border-t border-border flex flex-col gap-2">
                  <span className="text-lg md:text-xl font-bold text-primary text-center">
                    {service.price}
                  </span>
                  <Link to="/garages" className="w-full">
                    <Button className="w-full bg-accent hover:bg-accent/90 shadow-glow text-slate-800">
                      Réserver
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA Section */}
        <div className="text-center py-12 bg-secondary/30 rounded-lg">
          <h2 className="text-3xl font-bold mb-4 text-primary">Besoin d'un service spécifique ?</h2>
          <p className="text-muted-foreground mb-6">
            Contactez-nous pour un devis personnalisé
          </p>
          <Link to="/contact">
            <Button size="lg" className="bg-accent hover:bg-accent/90 shadow-glow">
              Demander un Devis
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Services;
