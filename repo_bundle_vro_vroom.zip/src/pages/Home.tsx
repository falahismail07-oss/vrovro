import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Wrench, Car, ShoppingCart, Truck, AlertCircle, FileCheck, 
  Shield, Clock, TrendingUp, Users, Star, ArrowRight, 
  MapPin, Phone, CheckCircle, Zap, Sparkles, Package, Palette
} from "lucide-react";
import heroImage from "@/assets/hero-garage.jpg";

const Home = () => {
  const mainServices = [
    {
      icon: MapPin,
      title: "Trouver un Garage",
      description: "Comparez et réservez parmi des centaines de garages certifiés",
      link: "/garages",
      color: "text-blue-500"
    },
    {
      icon: Wrench,
      title: "Services Auto",
      description: "Mécanique, peinture, vidange, diagnostic et bien plus",
      link: "/services",
      color: "text-orange-500"
    },
    {
      icon: ShoppingCart,
      title: "Accessoires",
      description: "Pneus, huiles, pièces détachées et équipements",
      link: "/accessoires",
      color: "text-green-500"
    },
    {
      icon: Car,
      title: "Location de Voiture",
      description: "Véhicules économiques et de luxe partout au Maroc",
      link: "/location-voiture",
      color: "text-purple-500"
    },
    {
      icon: Truck,
      title: "Dépannage 24/7",
      description: "Assistance et remorquage où que vous soyez",
      link: "/depannage-remorquage",
      color: "text-red-500"
    },
    {
      icon: FileCheck,
      title: "Constatateur",
      description: "Expertise automobile et constat amiable",
      link: "/constatateur",
      color: "text-cyan-500"
    }
  ];

  const featuredServices = [
    { icon: Wrench, name: "Mécanique Générale", price: "300 DH" },
    { icon: Palette, name: "Peinture & Carrosserie", price: "500 DH" },
    { icon: Sparkles, name: "Lavage Premium", price: "100 DH" },
    { icon: Zap, name: "Diagnostic Électronique", price: "150 DH" },
    { icon: Package, name: "Vidange Complète", price: "200 DH" },
    { icon: CheckCircle, name: "Contrôle Technique", price: "350 DH" }
  ];

  const avantagesClients = [
    {
      icon: Shield,
      title: "Garages Certifiés",
      description: "Tous nos partenaires sont vérifiés et qualifiés"
    },
    {
      icon: Clock,
      title: "Réservation Rapide",
      description: "Prenez rendez-vous en moins de 2 minutes"
    },
    {
      icon: TrendingUp,
      title: "Prix Transparents",
      description: "Comparez les tarifs avant de réserver"
    },
    {
      icon: Star,
      title: "Avis Clients",
      description: "Consultez les notes et commentaires réels"
    }
  ];

  const avantagesGarages = [
    {
      icon: Users,
      title: "Augmentez votre Clientèle",
      description: "Accédez à des milliers d'automobilistes"
    },
    {
      icon: Star,
      title: "Visibilité Maximale",
      description: "Apparaissez dans les recherches locales"
    },
    {
      icon: Zap,
      title: "Gestion Simplifiée",
      description: "Gérez vos réservations en ligne facilement"
    },
    {
      icon: TrendingUp,
      title: "Croissance Garantie",
      description: "Marketing et promotion inclus"
    }
  ];

  const stats = [
    { number: "500+", label: "Garages Partenaires" },
    { number: "10K+", label: "Clients Satisfaits" },
    { number: "50+", label: "Villes Couvertes" },
    { number: "24/7", label: "Support Client" }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[85vh] flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center" 
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-background/95 via-background/80 to-background" />
        </div>
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 text-gradient-silver animate-fade-in">
            Votre Plateforme Automobile
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-4 max-w-3xl mx-auto">
            Garages • Services • Accessoires • Location • Dépannage
          </p>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            La solution complète pour tous vos besoins automobiles au Maroc
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/garages">
              <Button size="lg" className="bg-accent hover:bg-accent/90 shadow-glow text-lg px-8 py-6 text-slate-800">
                Trouver un Garage
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link to="/services">
              <Button size="lg" variant="outline" className="text-lg px-8 py-6 border-primary text-primary hover:bg-primary hover:text-primary-foreground">
                Découvrir les Services
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-secondary/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-accent mb-2">
                  {stat.number}
                </div>
                <div className="text-sm md:text-base text-muted-foreground">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Main Services Section */}
      <section className="py-16 container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-primary">
            Tous vos Services en Un Seul Endroit
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            De la recherche de garage à la location de voiture, VRO vous accompagne
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mainServices.map((service, index) => (
            <Link key={index} to={service.link}>
              <Card className="shadow-elegant hover:shadow-glow transition-smooth h-full group cursor-pointer border-border hover:border-accent">
                <CardHeader className="text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/10 mb-4 mx-auto group-hover:scale-110 transition-smooth">
                    <service.icon className={`h-8 w-8 ${service.color}`} />
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                  <CardDescription className="text-base">
                    {service.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Services Quick View */}
      <section className="py-16 bg-secondary/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-primary">
              Services Populaires
            </h2>
            <p className="text-muted-foreground text-lg">
              Nos prestations les plus demandées
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {featuredServices.map((service, index) => (
              <Card key={index} className="shadow-elegant hover:shadow-glow transition-smooth text-center group cursor-pointer">
                <CardContent className="p-4">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-accent/10 mb-3 group-hover:bg-accent/20 transition-smooth">
                    <service.icon className="h-6 w-6 text-accent" />
                  </div>
                  <h3 className="text-sm font-semibold mb-2 line-clamp-2 min-h-[2.5rem]">
                    {service.name}
                  </h3>
                  <p className="text-primary font-bold text-sm">
                    {service.price}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-8">
            <Link to="/services">
              <Button size="lg" className="bg-accent hover:bg-accent/90 shadow-glow text-slate-800">
                Voir Tous les Services
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Avantages Automobilistes */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-primary">
              Pourquoi Choisir VRO ?
            </h2>
            <p className="text-muted-foreground text-lg">
              Des avantages pensés pour les automobilistes
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {avantagesClients.map((avantage, index) => (
              <Card key={index} className="shadow-elegant text-center group hover:shadow-glow transition-smooth">
                <CardContent className="p-6">
                  <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-accent/10 mb-4 group-hover:bg-accent/20 transition-smooth">
                    <avantage.icon className="h-7 w-7 text-accent" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2 text-primary">
                    {avantage.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {avantage.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Section Garagistes */}
      <section className="py-16 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-primary">
              Vous êtes Garagiste ?
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Rejoignez VRO et développez votre activité avec notre plateforme
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {avantagesGarages.map((avantage, index) => (
              <Card key={index} className="shadow-elegant border-border text-center group hover:shadow-glow transition-smooth">
                <CardContent className="p-6">
                  <avantage.icon className="h-12 w-12 mx-auto mb-4 text-primary group-hover:scale-110 transition-smooth" />
                  <h3 className="text-lg font-semibold mb-2 text-primary">
                    {avantage.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {avantage.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/garagistes">
              <Button size="lg" className="bg-primary hover:bg-primary/90 shadow-glow">
                En Savoir Plus
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link to="/inscription-garage">
              <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
                Inscrire Mon Garage
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Final Section */}
      <section className="py-16 bg-secondary/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <Phone className="h-16 w-16 mx-auto mb-6 text-accent" />
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-primary">
              Besoin d'Aide ou de Conseils ?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Notre équipe est à votre écoute pour répondre à toutes vos questions
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/contact">
                <Button size="lg" className="bg-accent hover:bg-accent/90 shadow-glow text-slate-800">
                  Contactez-nous
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/depannage-remorquage">
                <Button size="lg" variant="outline" className="border-red-500 text-red-500 hover:bg-red-500 hover:text-white">
                  <AlertCircle className="mr-2 h-5 w-5" />
                  Dépannage Urgent
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
