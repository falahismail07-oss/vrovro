import { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { marketplaceOffers } from '@/data/marketplaceOffers';
import { ArrowLeft, MapPin, Calendar, Paperclip, Mail, Phone, User, Car, FileText, Upload, Send } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const MarketplaceOfferDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const offer = marketplaceOffers.find(o => o.id === id);
  
  const [quotePrice, setQuotePrice] = useState('');
  const [quoteDays, setQuoteDays] = useState('');
  const [quoteMessage, setQuoteMessage] = useState('');
  const [quoteFile, setQuoteFile] = useState<File | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  if (!offer) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-muted-foreground mb-4">Offre non trouvée</p>
            <Button onClick={() => navigate('/marketplace')}>
              Retour à la marketplace
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleSubmitQuote = (e: React.FormEvent) => {
    e.preventDefault();

    // Simulation de l'envoi
    toast({
      title: "Devis soumis avec succès !",
      description: `Votre offre de ${quotePrice} DH a été envoyée à ${offer.clientName}. Vous recevrez une notification dès que le client aura consulté votre proposition.`,
    });

    // Réinitialiser le formulaire
    setQuotePrice('');
    setQuoteDays('');
    setQuoteMessage('');
    setQuoteFile(null);
    setIsDialogOpen(false);

    // Rediriger vers le tableau de bord après 2 secondes
    setTimeout(() => {
      navigate('/marketplace-dashboard');
    }, 2000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ouverte': return 'bg-green-500/10 text-green-600 border-green-500/20';
      case 'réservée': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
      case 'fermée': return 'bg-slate-500/10 text-slate-600 border-slate-500/20';
      default: return '';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <Button variant="ghost" onClick={() => navigate('/marketplace')} className="mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Retour à la marketplace
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-2xl">{offer.title}</CardTitle>
                    <CardDescription className="mt-2">
                      Référence: {offer.id}
                    </CardDescription>
                  </div>
                  <Badge className={getStatusColor(offer.status)} variant="outline">
                    {offer.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Images */}
                <div className="grid grid-cols-2 gap-4">
                  {offer.images.map((img, idx) => (
                    <div key={idx} className="aspect-video rounded-lg overflow-hidden bg-muted">
                      <img src={img} alt={`${offer.title} ${idx + 1}`} className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>

                {/* Description */}
                <div>
                  <h3 className="font-semibold mb-2">Description détaillée</h3>
                  <p className="text-muted-foreground">{offer.description}</p>
                </div>

                {/* Details */}
                <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                  <div className="flex items-center gap-2 text-sm">
                    <Badge variant="secondary">{offer.serviceType}</Badge>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="w-4 h-4" />
                    {offer.city}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="w-4 h-4" />
                    {new Date(offer.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}
                  </div>
                  {offer.attachments > 0 && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Paperclip className="w-4 h-4" />
                      {offer.attachments} pièce{offer.attachments > 1 ? 's' : ''} jointe{offer.attachments > 1 ? 's' : ''}
                    </div>
                  )}
                </div>

                {offer.carBrand && (
                  <div className="pt-4 border-t">
                    <h3 className="font-semibold mb-2 flex items-center gap-2">
                      <Car className="w-4 h-4" />
                      Véhicule concerné
                    </h3>
                    <p className="text-muted-foreground">
                      {offer.carBrand} {offer.carModel}
                    </p>
                  </div>
                )}

                {/* Budget */}
                <div className="p-4 bg-primary/5 rounded-lg border border-primary/10">
                  <p className="text-sm text-muted-foreground mb-1">Budget indicatif du client</p>
                  <p className="text-2xl font-bold text-primary">
                    {offer.budgetMin.toLocaleString()} - {offer.budgetMax.toLocaleString()} DH
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Client Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Informations client</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <span>{offer.clientName}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">{offer.clientEmail}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">{offer.clientPhone}</span>
                </div>
              </CardContent>
            </Card>

            {/* Submit Quote */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Soumettre un devis</CardTitle>
                <CardDescription>
                  Proposez votre offre pour cette demande
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="w-full" size="lg" disabled={offer.status === 'fermée'}>
                      <FileText className="w-4 h-4 mr-2" />
                      Soumettre un devis
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Soumettre votre devis</DialogTitle>
                      <DialogDescription>
                        Remplissez les informations ci-dessous pour soumettre votre proposition au client
                      </DialogDescription>
                    </DialogHeader>

                    <form onSubmit={handleSubmitQuote} className="space-y-4 mt-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="price">Prix proposé (DH) *</Label>
                          <Input
                            id="price"
                            type="number"
                            placeholder="Ex: 3500"
                            value={quotePrice}
                            onChange={(e) => setQuotePrice(e.target.value)}
                            required
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="days">Délai estimé (jours) *</Label>
                          <Input
                            id="days"
                            type="number"
                            placeholder="Ex: 3"
                            value={quoteDays}
                            onChange={(e) => setQuoteDays(e.target.value)}
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="message">Message au client *</Label>
                        <Textarea
                          id="message"
                          placeholder="Décrivez votre proposition, les pièces incluses, votre expertise..."
                          value={quoteMessage}
                          onChange={(e) => setQuoteMessage(e.target.value)}
                          rows={5}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="file">Joindre un document (optionnel)</Label>
                        <div className="flex items-center gap-2">
                          <Input
                            id="file"
                            type="file"
                            accept=".pdf,.jpg,.jpeg,.png"
                            onChange={(e) => setQuoteFile(e.target.files?.[0] || null)}
                            className="cursor-pointer"
                          />
                          <Upload className="w-4 h-4 text-muted-foreground" />
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Formats acceptés: PDF, JPG, PNG (max 20MB)
                        </p>
                      </div>

                      <div className="p-4 bg-muted rounded-lg">
                        <h4 className="font-medium mb-2 text-sm">Récapitulatif de votre offre</h4>
                        <div className="space-y-1 text-sm text-muted-foreground">
                          <p>Prix: <span className="font-semibold text-foreground">{quotePrice || '—'} DH</span></p>
                          <p>Délai: <span className="font-semibold text-foreground">{quoteDays || '—'} jour{quoteDays && parseInt(quoteDays) > 1 ? 's' : ''}</span></p>
                        </div>
                      </div>

                      <Button type="submit" className="w-full" size="lg">
                        <Send className="w-4 h-4 mr-2" />
                        Envoyer le devis
                      </Button>
                    </form>
                  </DialogContent>
                </Dialog>

                {offer.status === 'fermée' && (
                  <p className="text-xs text-muted-foreground mt-2 text-center">
                    Cette offre est fermée
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Back to list */}
            <Link to="/marketplace">
              <Button variant="outline" className="w-full">
                Voir toutes les offres
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarketplaceOfferDetail;
