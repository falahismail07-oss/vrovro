import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Users, TrendingUp, Zap, Calendar, BarChart3, Smartphone, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import garagistesHero from "@/assets/garagistes-hero.jpg";

const Garagistes = () => {
  const avantages = [
    {
      icon: Users,
      title: "Plus de Clients",
      description: "Augmentez votre visibilité et attirez de nouveaux clients chaque jour",
    },
    {
      icon: TrendingUp,
      title: "Revenus en Hausse",
      description: "Optimisez votre taux de remplissage et maximisez vos revenus",
    },
    {
      icon: Zap,
      title: "Marketing Automatique",
      description: "Nous gérons votre présence en ligne et vos campagnes marketing",
    },
    {
      icon: Calendar,
      title: "Réservations Automatiques",
      description: "Système de réservation en ligne 24/7 sans intervention manuelle",
    },
    {
      icon: BarChart3,
      title: "Statistiques Détaillées",
      description: "Tableau de bord complet pour suivre vos performances",
    },
    {
      icon: Smartphone,
      title: "Gestion Mobile",
      description: "Gérez votre activité depuis votre smartphone où que vous soyez",
    },
  ];

  const stats = [
    { value: "300+", label: "Garages Partenaires" },
    { value: "15K+", label: "Réservations/Mois" },
    { value: "4.8/5", label: "Satisfaction Client" },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section 
        className="relative h-[70vh] flex items-center justify-center bg-cover bg-center"
        style={{ backgroundImage: `url(${garagistesHero})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-background/90 via-background/70 to-background" />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-gradient-silver">
            Développez Votre Garage Sans Effort
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Rejoignez la plateforme n°1 de digitalisation des garages au Maroc et attirez plus de clients
          </p>
          <Link to="/inscription-garage">
            <Button size="lg" className="bg-accent hover:bg-accent/90 shadow-glow text-lg px-8 py-6">
              Inscrire Mon Garage
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-secondary/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            {stats.map((stat, index) => (
              <div key={index}>
                <div className="text-4xl font-bold text-primary mb-2">{stat.value}</div>
                <div className="text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Avantages */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 text-primary">Pourquoi Rejoindre Vro ?</h2>
            <p className="text-lg text-muted-foreground">Des outils puissants pour développer votre activité</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {avantages.map((avantage, index) => (
              <Card key={index} className="shadow-elegant hover:shadow-glow transition-smooth">
                <CardContent className="p-6">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-accent/10 mb-4">
                    <avantage.icon className="h-6 w-6 text-accent" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2 text-primary">{avantage.title}</h3>
                  <p className="text-muted-foreground">{avantage.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Dashboard Preview */}
      <section className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 text-primary">Tableau de Bord Intuitif</h2>
            <p className="text-lg text-muted-foreground">Gérez votre activité en toute simplicité</p>
          </div>

          <div className="bg-card rounded-lg shadow-elegant p-8 border border-border">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-secondary/50 p-6 rounded-lg">
                <div className="text-3xl font-bold text-accent mb-2">245</div>
                <div className="text-muted-foreground">Réservations ce mois</div>
              </div>
              <div className="bg-secondary/50 p-6 rounded-lg">
                <div className="text-3xl font-bold text-accent mb-2">45K DH</div>
                <div className="text-muted-foreground">Chiffre d'affaires</div>
              </div>
              <div className="bg-secondary/50 p-6 rounded-lg">
                <div className="text-3xl font-bold text-accent mb-2">4.9/5</div>
                <div className="text-muted-foreground">Note moyenne</div>
              </div>
            </div>
            <p className="text-center text-muted-foreground">
              Accédez à vos statistiques en temps réel et optimisez votre activité
            </p>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-4 text-primary">Prêt à Rejoindre Vro ?</h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Commencez dès aujourd'hui et transformez votre garage en une entreprise digitale moderne
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/inscription-garage">
              <Button size="lg" className="bg-accent hover:bg-accent/90 shadow-glow">
                Inscription Gratuite
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link to="/services-premium">
              <Button size="lg" variant="secondary">
                Découvrir les Packs Premium
              </Button>
            </Link>
            <Link to="/contact">
              <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
                Demander une Démo
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Garagistes;
