import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Car, Fuel, Users, Settings } from "lucide-react";

const CarRental = () => {
  const [selectedCity, setSelectedCity] = useState("all");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [priceRange, setPriceRange] = useState([200, 5000]);
  const [searchQuery, setSearchQuery] = useState("");

  const vehicles = [
    {
      id: 1,
      name: "Dacia Sandero",
      category: "Économique",
      city: "Casablanca",
      price: 350,
      image: "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=800",
      available: true,
      seats: 5,
      transmission: "Manuelle",
      fuel: "Essence"
    },
    {
      id: 2,
      name: "Renault Clio",
      category: "Économique",
      city: "Rabat",
      price: 400,
      image: "https://images.unsplash.com/photo-1550355291-bbee04a92027?w=800",
      available: true,
      seats: 5,
      transmission: "Manuelle",
      fuel: "Diesel"
    },
    {
      id: 3,
      name: "Peugeot 3008",
      category: "SUV",
      city: "Marrakech",
      price: 800,
      image: "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=800",
      available: true,
      seats: 5,
      transmission: "Automatique",
      fuel: "Diesel"
    },
    {
      id: 4,
      name: "Mercedes GLE",
      category: "Luxe",
      city: "Casablanca",
      price: 2500,
      image: "https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800",
      available: true,
      seats: 5,
      transmission: "Automatique",
      fuel: "Essence"
    },
    {
      id: 5,
      name: "Range Rover Sport",
      category: "Luxe",
      city: "Tanger",
      price: 3000,
      image: "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800",
      available: true,
      seats: 5,
      transmission: "Automatique",
      fuel: "Diesel"
    },
    {
      id: 6,
      name: "BMW X5",
      category: "SUV",
      city: "Casablanca",
      price: 1800,
      image: "https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800",
      available: true,
      seats: 5,
      transmission: "Automatique",
      fuel: "Essence"
    },
    {
      id: 7,
      name: "Mercedes G63 AMG",
      category: "Luxe",
      city: "Marrakech",
      price: 5000,
      image: "https://images.unsplash.com/photo-1617531653520-bd466ee5f936?w=800",
      available: false,
      seats: 5,
      transmission: "Automatique",
      fuel: "Essence"
    },
    {
      id: 8,
      name: "Toyota Land Cruiser",
      category: "SUV",
      city: "Agadir",
      price: 1500,
      image: "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=800",
      available: true,
      seats: 7,
      transmission: "Automatique",
      fuel: "Diesel"
    },
  ];

  const categories = [
    { value: "Économique", icon: Car, description: "Pratiques et abordables pour les trajets quotidiens" },
    { value: "SUV", icon: Car, description: "Puissance et confort pour vos aventures" },
    { value: "Luxe", icon: Car, description: "Mercedes, BMW, Range Rover, pour vos occasions spéciales" },
    { value: "Sportive", icon: Car, description: "Ferrari, Lamborghini, Porsche (sur demande)" },
  ];

  const filteredVehicles = vehicles.filter((vehicle) => {
    const matchesCity = selectedCity === "all" || vehicle.city === selectedCity;
    const matchesCategory = selectedCategory === "all" || vehicle.category === selectedCategory;
    const matchesPrice = vehicle.price >= priceRange[0] && vehicle.price <= priceRange[1];
    const matchesSearch = vehicle.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCity && matchesCategory && matchesPrice && matchesSearch;
  });

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[400px] flex items-center justify-center bg-gradient-to-r from-primary/20 to-accent/20 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-30"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=1600')" }}
        />
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
            🚘 Louez la voiture qu'il vous faut au meilleur prix
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground">
            Découvrez nos véhicules disponibles partout au Maroc — de la citadine économique au SUV ou voiture de luxe.
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 py-12">
        {/* Filters Section */}
        <Card className="mb-8 shadow-elegant">
          <CardHeader>
            <CardTitle>Filtres de recherche</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Search */}
              <div>
                <Label htmlFor="search">Rechercher</Label>
                <Input
                  id="search"
                  placeholder="Ex: Mercedes, Dacia..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              {/* City Filter */}
              <div>
                <Label htmlFor="city">Ville</Label>
                <Select value={selectedCity} onValueChange={setSelectedCity}>
                  <SelectTrigger id="city">
                    <SelectValue placeholder="Sélectionner une ville" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Toutes les villes</SelectItem>
                    <SelectItem value="Casablanca">Casablanca</SelectItem>
                    <SelectItem value="Rabat">Rabat</SelectItem>
                    <SelectItem value="Marrakech">Marrakech</SelectItem>
                    <SelectItem value="Tanger">Tanger</SelectItem>
                    <SelectItem value="Agadir">Agadir</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Category Filter */}
              <div>
                <Label htmlFor="category">Catégorie</Label>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger id="category">
                    <SelectValue placeholder="Catégorie" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Toutes catégories</SelectItem>
                    <SelectItem value="Économique">Économique</SelectItem>
                    <SelectItem value="SUV">SUV</SelectItem>
                    <SelectItem value="Luxe">Luxe</SelectItem>
                    <SelectItem value="Sportive">Sportive</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Price Range */}
              <div>
                <Label>Prix par jour: {priceRange[0]} - {priceRange[1]} DH</Label>
                <Slider
                  min={200}
                  max={5000}
                  step={100}
                  value={priceRange}
                  onValueChange={setPriceRange}
                  className="mt-2"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Vehicle Catalog */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {filteredVehicles.map((vehicle) => (
            <Card key={vehicle.id} className="overflow-hidden hover-scale shadow-elegant">
              <div className="relative h-48 overflow-hidden">
                <img
                  src={vehicle.image}
                  alt={vehicle.name}
                  className="w-full h-full object-cover"
                />
                {!vehicle.available && (
                  <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                    <span className="text-white font-semibold">Sur demande</span>
                  </div>
                )}
                <div className="absolute top-2 right-2 bg-accent text-slate-800 px-3 py-1 rounded-full text-sm font-semibold">
                  {vehicle.category}
                </div>
              </div>
              <CardHeader>
                <CardTitle className="text-xl">{vehicle.name}</CardTitle>
                <p className="text-sm text-muted-foreground">{vehicle.city}</p>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                  <div className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    <span>{vehicle.seats} places</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Settings className="w-4 h-4" />
                    <span>{vehicle.transmission}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Fuel className="w-4 h-4" />
                    <span>{vehicle.fuel}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-primary">{vehicle.price} DH<span className="text-sm text-muted-foreground">/jour</span></span>
                </div>
              </CardContent>
              <CardFooter>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="w-full bg-accent hover:bg-accent/90 shadow-glow text-slate-800">
                      Réserver maintenant
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md">
                    <DialogHeader>
                      <DialogTitle>Réserver {vehicle.name}</DialogTitle>
                    </DialogHeader>
                    <form className="space-y-4">
                      <div>
                        <Label htmlFor="fullname">Nom complet *</Label>
                        <Input id="fullname" required />
                      </div>
                      <div>
                        <Label htmlFor="phone">Téléphone *</Label>
                        <Input id="phone" type="tel" required />
                      </div>
                      <div>
                        <Label htmlFor="rental-city">Ville *</Label>
                        <Input id="rental-city" defaultValue={vehicle.city} />
                      </div>
                      <div>
                        <Label htmlFor="start-date">Date de début *</Label>
                        <Input id="start-date" type="date" required />
                      </div>
                      <div>
                        <Label htmlFor="end-date">Date de fin *</Label>
                        <Input id="end-date" type="date" required />
                      </div>
                      <div>
                        <Label htmlFor="id-upload">Carte d'identité / Permis</Label>
                        <Input id="id-upload" type="file" accept=".jpg,.png,.pdf" />
                      </div>
                      <Button type="submit" className="w-full bg-accent hover:bg-accent/90">
                        Envoyer la demande
                      </Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </CardFooter>
            </Card>
          ))}
        </div>

        {/* Categories Section */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-center mb-8">Nos gammes de véhicules</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((cat) => (
              <Card
                key={cat.value}
                className="hover-scale cursor-pointer shadow-elegant"
                onClick={() => setSelectedCategory(cat.value)}
              >
                <CardHeader className="text-center">
                  <div className="mx-auto mb-4 w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center">
                    <cat.icon className="w-8 h-8 text-accent" />
                  </div>
                  <CardTitle>{cat.value}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground text-center">{cat.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Info Section */}
        <section className="bg-muted/50 rounded-lg p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Avec Vro Maroc, trouvez facilement une voiture de location adaptée à vos besoins</h2>
          <p className="text-muted-foreground mb-6">
            Que ce soit pour un déplacement professionnel, un week-end ou un événement, profitez de nos offres exclusives avec ou sans chauffeur.
          </p>
          <Button className="bg-primary hover:bg-primary/90 shadow-glow">
            Devenir partenaire loueur
          </Button>
        </section>
      </div>
    </div>
  );
};

export default CarRental;