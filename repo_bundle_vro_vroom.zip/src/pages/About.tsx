import { Card, CardContent } from "@/components/ui/card";
import { Target, Users, Rocket } from "lucide-react";

const About = () => {
  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gradient-silver">
            À Propos de Vro Maroc
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Révolutionner l'industrie automobile marocaine grâce à la digitalisation
          </p>
        </div>

        {/* Mission */}
        <section className="mb-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="shadow-elegant">
              <CardContent className="p-6 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/10 mb-4">
                  <Target className="h-8 w-8 text-accent" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-primary">Notre Mission</h3>
                <p className="text-muted-foreground">
                  Digitaliser les garages automobiles au Maroc pour offrir une expérience moderne et transparente
                </p>
              </CardContent>
            </Card>

            <Card className="shadow-elegant">
              <CardContent className="p-6 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/10 mb-4">
                  <Users className="h-8 w-8 text-accent" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-primary">Notre Vision</h3>
                <p className="text-muted-foreground">
                  Devenir la plateforme de référence pour tous les besoins automobiles au Maroc
                </p>
              </CardContent>
            </Card>

            <Card className="shadow-elegant">
              <CardContent className="p-6 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/10 mb-4">
                  <Rocket className="h-8 w-8 text-accent" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-primary">Nos Valeurs</h3>
                <p className="text-muted-foreground">
                  Innovation, transparence, qualité et satisfaction client au cœur de nos priorités
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Story */}
        <section className="mb-16">
          <div className="bg-secondary/30 rounded-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold mb-6 text-primary">Notre Histoire</h2>
            <div className="space-y-4 text-muted-foreground">
              <p>
                Vro Maroc est née de la volonté de moderniser l'industrie automobile marocaine et de faciliter 
                la vie des automobilistes. Nous avons constaté que trouver un garage de confiance, comparer 
                les prix et réserver des services était un processus souvent complexe et opaque.
              </p>
              <p>
                Notre plateforme connecte les automobilistes avec les meilleurs garages du Maroc, offrant 
                transparence, simplicité et rapidité. Nous aidons également les garagistes à développer 
                leur activité en leur fournissant les outils digitaux nécessaires pour attirer et fidéliser 
                leurs clients.
              </p>
              <p>
                Aujourd'hui, Vro Maroc est fière de compter plus de 300 garages partenaires et de faciliter 
                des milliers de réservations chaque mois à travers le royaume.
              </p>
            </div>
          </div>
        </section>

        {/* Team */}
        <section className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4 text-primary">Notre Équipe</h2>
            <p className="text-muted-foreground">Des passionnés d'automobile et de technologie</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="text-center">
                <div className="w-32 h-32 rounded-full bg-secondary/50 mx-auto mb-4" />
                <h3 className="font-semibold text-primary">Membre {i}</h3>
                <p className="text-sm text-muted-foreground">Fonction</p>
              </div>
            ))}
          </div>
        </section>

        {/* Partners */}
        <section>
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4 text-primary">Nos Partenaires</h2>
            <p className="text-muted-foreground">Ils nous font confiance</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[1, 2, 3, 4].map((i) => (
              <div 
                key={i} 
                className="h-24 bg-secondary/30 rounded-lg flex items-center justify-center border border-border"
              >
                <span className="text-muted-foreground text-sm">Partenaire {i}</span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default About;
