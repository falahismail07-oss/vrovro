import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { Building2, MapPin, Phone, Mail, Clock, Wrench } from "lucide-react";

const garageRegistrationSchema = z.object({
  garageName: z.string().trim().min(2, "Le nom doit contenir au moins 2 caractères").max(100),
  ownerName: z.string().trim().min(2, "Le nom du propriétaire est requis").max(100),
  email: z.string().trim().email("Email invalide").max(255),
  phone: z.string().trim().min(10, "Numéro de téléphone invalide").max(20),
  address: z.string().trim().min(5, "Adresse complète requise").max(200),
  city: z.string().trim().min(2, "Ville requise").max(50),
  postalCode: z.string().trim().optional(),
  description: z.string().trim().max(1000, "Description trop longue").optional(),
  services: z.array(z.string()).min(1, "Sélectionnez au moins un service"),
  openingHours: z.string().trim().max(200).optional(),
  licenseNumber: z.string().trim().min(3, "Numéro de licence requis").max(50),
  yearsInBusiness: z.string().trim().optional(),
});

type FormData = z.infer<typeof garageRegistrationSchema>;

const GarageRegistration = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const availableServices = [
    "Mécanique Générale",
    "Peinture & Carrosserie",
    "Vidange & Entretien",
    "Diagnostic Électronique",
    "Climatisation",
    "Lavage Premium",
    "Géométrie & Parallélisme",
    "Contrôle Technique",
    "Électricité Auto",
    "Montage Pneus",
    "Freinage",
    "Dépannage",
  ];

  const [selectedServices, setSelectedServices] = useState<string[]>([]);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<FormData>({
    resolver: zodResolver(garageRegistrationSchema),
  });

  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    try {
      // Add selected services to form data
      const formData = { ...data, services: selectedServices };
      
      // TODO: Implement actual submission logic (e.g., Supabase)
      console.log("Form submitted:", formData);
      
      toast({
        title: "Inscription réussie !",
        description: "Votre demande a été envoyée. Nous vous contacterons sous peu.",
      });
      
      reset();
      setSelectedServices([]);
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Une erreur est survenue. Veuillez réessayer.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleServiceToggle = (service: string) => {
    setSelectedServices((prev) =>
      prev.includes(service)
        ? prev.filter((s) => s !== service)
        : [...prev, service]
    );
  };

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gradient-silver">
            Rejoignez VRO Maroc
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Inscrivez votre garage et développez votre activité avec notre plateforme digitale
          </p>
        </div>

        {/* Benefits Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="shadow-elegant">
            <CardHeader>
              <CardTitle className="text-primary text-lg">Plus de Visibilité</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Augmentez votre présence en ligne et attirez de nouveaux clients
              </p>
            </CardContent>
          </Card>
          <Card className="shadow-elegant">
            <CardHeader>
              <CardTitle className="text-primary text-lg">Réservations Faciles</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Gérez vos rendez-vous en ligne automatiquement
              </p>
            </CardContent>
          </Card>
          <Card className="shadow-elegant">
            <CardHeader>
              <CardTitle className="text-primary text-lg">Marketing Inclus</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Profitez de nos campagnes marketing sans effort supplémentaire
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Registration Form */}
        <Card className="shadow-elegant">
          <CardHeader>
            <CardTitle className="text-2xl text-primary">Formulaire d'Inscription</CardTitle>
            <CardDescription>
              Remplissez les informations ci-dessous pour rejoindre notre réseau
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* Business Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-primary flex items-center">
                  <Building2 className="h-5 w-5 mr-2" />
                  Informations du Garage
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="garageName">Nom du Garage *</Label>
                    <Input
                      id="garageName"
                      {...register("garageName")}
                      placeholder="Auto Premium Service"
                    />
                    {errors.garageName && (
                      <p className="text-sm text-destructive">{errors.garageName.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="licenseNumber">Numéro de Licence *</Label>
                    <Input
                      id="licenseNumber"
                      {...register("licenseNumber")}
                      placeholder="LIC-123456"
                    />
                    {errors.licenseNumber && (
                      <p className="text-sm text-destructive">{errors.licenseNumber.message}</p>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description du Garage</Label>
                  <Textarea
                    id="description"
                    {...register("description")}
                    placeholder="Décrivez vos services et spécialités..."
                    rows={3}
                  />
                  {errors.description && (
                    <p className="text-sm text-destructive">{errors.description.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="yearsInBusiness">Années d'Expérience</Label>
                  <Input
                    id="yearsInBusiness"
                    {...register("yearsInBusiness")}
                    type="number"
                    placeholder="5"
                  />
                </div>
              </div>

              {/* Owner Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-primary flex items-center">
                  <Mail className="h-5 w-5 mr-2" />
                  Informations du Propriétaire
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="ownerName">Nom Complet *</Label>
                    <Input
                      id="ownerName"
                      {...register("ownerName")}
                      placeholder="Mohammed Alami"
                    />
                    {errors.ownerName && (
                      <p className="text-sm text-destructive">{errors.ownerName.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Téléphone *</Label>
                    <Input
                      id="phone"
                      {...register("phone")}
                      placeholder="+212 6XX-XXXXXX"
                    />
                    {errors.phone && (
                      <p className="text-sm text-destructive">{errors.phone.message}</p>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    {...register("email")}
                    placeholder="contact@garage.ma"
                  />
                  {errors.email && (
                    <p className="text-sm text-destructive">{errors.email.message}</p>
                  )}
                </div>
              </div>

              {/* Location */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-primary flex items-center">
                  <MapPin className="h-5 w-5 mr-2" />
                  Localisation
                </h3>
                
                <div className="space-y-2">
                  <Label htmlFor="address">Adresse Complète *</Label>
                  <Input
                    id="address"
                    {...register("address")}
                    placeholder="123 Avenue Mohammed V"
                  />
                  {errors.address && (
                    <p className="text-sm text-destructive">{errors.address.message}</p>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="city">Ville *</Label>
                    <Input
                      id="city"
                      {...register("city")}
                      placeholder="Casablanca"
                    />
                    {errors.city && (
                      <p className="text-sm text-destructive">{errors.city.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="postalCode">Code Postal</Label>
                    <Input
                      id="postalCode"
                      {...register("postalCode")}
                      placeholder="20000"
                    />
                  </div>
                </div>
              </div>

              {/* Services */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-primary flex items-center">
                  <Wrench className="h-5 w-5 mr-2" />
                  Services Offerts *
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {availableServices.map((service) => (
                    <div key={service} className="flex items-center space-x-2">
                      <Checkbox
                        id={service}
                        checked={selectedServices.includes(service)}
                        onCheckedChange={() => handleServiceToggle(service)}
                      />
                      <Label
                        htmlFor={service}
                        className="text-sm font-normal cursor-pointer"
                      >
                        {service}
                      </Label>
                    </div>
                  ))}
                </div>
                {selectedServices.length === 0 && (
                  <p className="text-sm text-destructive">Sélectionnez au moins un service</p>
                )}
              </div>

              {/* Operating Hours */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-primary flex items-center">
                  <Clock className="h-5 w-5 mr-2" />
                  Horaires d'Ouverture
                </h3>
                
                <div className="space-y-2">
                  <Label htmlFor="openingHours">Horaires</Label>
                  <Input
                    id="openingHours"
                    {...register("openingHours")}
                    placeholder="Lun-Sam: 8h-18h"
                  />
                </div>
              </div>

              {/* Submit Button */}
              <div className="flex justify-end pt-6">
                <Button
                  type="submit"
                  disabled={isSubmitting || selectedServices.length === 0}
                  className="bg-accent hover:bg-accent/90 shadow-glow w-full md:w-auto"
                  size="lg"
                >
                  {isSubmitting ? "Envoi en cours..." : "Soumettre ma Demande"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default GarageRegistration;
