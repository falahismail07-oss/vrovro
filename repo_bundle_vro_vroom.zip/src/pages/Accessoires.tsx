import { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ShoppingCart } from "lucide-react";
import accessoriesHero from "@/assets/accessories-hero.jpg";
import productTire from "@/assets/product-tire.jpg";
import productOil from "@/assets/product-oil.jpg";
import productFilter from "@/assets/product-filter.jpg";
import productWipers from "@/assets/product-wipers.jpg";
import productBattery from "@/assets/product-battery.jpg";
import productLed from "@/assets/product-led.jpg";
import productBrakes from "@/assets/product-brakes.jpg";
import productPaint from "@/assets/product-paint.jpg";
import productWheel from "@/assets/product-wheel.jpg";
import productSparkplugs from "@/assets/product-sparkplugs.jpg";
import productCoolant from "@/assets/product-coolant.jpg";
import productBrakefluid from "@/assets/product-brakefluid.jpg";
import productBulbs from "@/assets/product-bulbs.jpg";
import productCabinFilter from "@/assets/product-cabin-filter.jpg";
import productTransmission from "@/assets/product-transmission.jpg";
import productWax from "@/assets/product-wax.jpg";

const Accessoires = () => {
  const [selectedCategory, setSelectedCategory] = useState("all");

  const products = [
    // Pneus
    {
      id: 1,
      name: "Pneus Premium 205/55 R16",
      category: "Pneus",
      price: "850 DH",
      image: productTire,
    },
    {
      id: 2,
      name: "Pneus Tout Terrain 215/65 R16",
      category: "Pneus",
      price: "920 DH",
      image: productTire,
    },
    {
      id: 3,
      name: "Pneus Sport 225/45 R17",
      category: "Pneus",
      price: "1150 DH",
      image: productTire,
    },
    // Huiles
    {
      id: 4,
      name: "Huile Moteur 5W40 5L",
      category: "Huiles",
      price: "320 DH",
      image: productOil,
    },
    {
      id: 5,
      name: "Huile Moteur 10W40 5L",
      category: "Huiles",
      price: "280 DH",
      image: productOil,
    },
    {
      id: 6,
      name: "Huile Transmission ATF 1L",
      category: "Huiles",
      price: "95 DH",
      image: productTransmission,
    },
    {
      id: 7,
      name: "Huile Synthétique 0W30 5L",
      category: "Huiles",
      price: "450 DH",
      image: productOil,
    },
    // Filtres
    {
      id: 8,
      name: "Filtre à Air Sport",
      category: "Filtres",
      price: "450 DH",
      image: productFilter,
    },
    {
      id: 9,
      name: "Filtre à Huile Premium",
      category: "Filtres",
      price: "85 DH",
      image: productFilter,
    },
    {
      id: 10,
      name: "Filtre Habitacle Charbon",
      category: "Filtres",
      price: "120 DH",
      image: productCabinFilter,
    },
    {
      id: 11,
      name: "Filtre à Carburant",
      category: "Filtres",
      price: "95 DH",
      image: productFilter,
    },
    // Pièces
    {
      id: 12,
      name: "Batterie 70Ah",
      category: "Pièces",
      price: "750 DH",
      image: productBattery,
    },
    {
      id: 13,
      name: "Batterie 90Ah Premium",
      category: "Pièces",
      price: "950 DH",
      image: productBattery,
    },
    {
      id: 14,
      name: "Kit Plaquettes de Frein",
      category: "Pièces",
      price: "380 DH",
      image: productBrakes,
    },
    {
      id: 15,
      name: "Plaquettes Frein Sport",
      category: "Pièces",
      price: "520 DH",
      image: productBrakes,
    },
    {
      id: 16,
      name: "Kit Bougies d'Allumage",
      category: "Pièces",
      price: "180 DH",
      image: productSparkplugs,
    },
    {
      id: 17,
      name: "Bougies Platine Longue Durée",
      category: "Pièces",
      price: "290 DH",
      image: productSparkplugs,
    },
    // Roues
    {
      id: 18,
      name: "Jante Alu 16 pouces Silver",
      category: "Roues",
      price: "1250 DH",
      image: productWheel,
    },
    {
      id: 19,
      name: "Jante Alu 17 pouces Sport",
      category: "Roues",
      price: "1450 DH",
      image: productWheel,
    },
    {
      id: 20,
      name: "Jante Alu 18 pouces Black",
      category: "Roues",
      price: "1650 DH",
      image: productWheel,
    },
    // Peinture
    {
      id: 21,
      name: "Bombe Peinture Noir Mat",
      category: "Peinture",
      price: "65 DH",
      image: productPaint,
    },
    {
      id: 22,
      name: "Bombe Peinture Gris Métal",
      category: "Peinture",
      price: "75 DH",
      image: productPaint,
    },
    {
      id: 23,
      name: "Kit Retouche Peinture",
      category: "Peinture",
      price: "120 DH",
      image: productPaint,
    },
    {
      id: 24,
      name: "Vernis Protecteur Spray",
      category: "Peinture",
      price: "85 DH",
      image: productPaint,
    },
    // Fluides
    {
      id: 25,
      name: "Liquide de Refroidissement 5L",
      category: "Fluides",
      price: "150 DH",
      image: productCoolant,
    },
    {
      id: 26,
      name: "Liquide de Frein DOT 4 1L",
      category: "Fluides",
      price: "75 DH",
      image: productBrakefluid,
    },
    {
      id: 27,
      name: "Lave-Glace Concentré 5L",
      category: "Fluides",
      price: "45 DH",
      image: productCoolant,
    },
    // Éclairage
    {
      id: 28,
      name: "Kit Éclairage LED",
      category: "Éclairage",
      price: "590 DH",
      image: productLed,
    },
    {
      id: 29,
      name: "Ampoules H7 LED Blanc",
      category: "Éclairage",
      price: "280 DH",
      image: productBulbs,
    },
    {
      id: 30,
      name: "Ampoules H4 Halogène",
      category: "Éclairage",
      price: "120 DH",
      image: productBulbs,
    },
    {
      id: 31,
      name: "Bande LED Intérieur RGB",
      category: "Éclairage",
      price: "220 DH",
      image: productLed,
    },
    // Accessoires
    {
      id: 32,
      name: "Kit Balais d'Essuie-Glace",
      category: "Accessoires",
      price: "180 DH",
      image: productWipers,
    },
    {
      id: 33,
      name: "Cire de Lustrage Premium",
      category: "Accessoires",
      price: "145 DH",
      image: productWax,
    },
    {
      id: 34,
      name: "Kit Nettoyage Complet",
      category: "Accessoires",
      price: "250 DH",
      image: productWax,
    },
    {
      id: 35,
      name: "Tapis de Sol Caoutchouc",
      category: "Accessoires",
      price: "320 DH",
      image: productWipers,
    },
  ];

  const categories = ["all", "Pneus", "Huiles", "Filtres", "Pièces", "Roues", "Peinture", "Fluides", "Éclairage", "Accessoires"];

  const filteredProducts = selectedCategory === "all"
    ? products
    : products.filter((p) => p.category === selectedCategory);

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section 
        className="relative h-64 flex items-center justify-center bg-cover bg-center"
        style={{ backgroundImage: `url(${accessoriesHero})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 to-background" />
        <div className="relative z-10 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gradient-silver mb-4">
            Accessoires Automobiles
          </h1>
          <p className="text-lg text-muted-foreground">
            Produits de qualité pour votre véhicule
          </p>
        </div>
      </section>

      {/* Content */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Filter */}
        <div className="mb-8 flex justify-between items-center">
          <h2 className="text-2xl font-semibold text-primary">Catalogue</h2>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Catégorie" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Toutes catégories</SelectItem>
              {categories.slice(1).map((cat) => (
                <SelectItem key={cat} value={cat}>
                  {cat}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
          {filteredProducts.map((product) => (
            <Card key={product.id} className="shadow-elegant hover:shadow-glow transition-smooth overflow-hidden group">
              <CardHeader className="p-4">
                <div className="aspect-square bg-muted/30 rounded-lg mb-3 overflow-hidden flex items-center justify-center">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-full object-contain p-2 group-hover:scale-105 transition-smooth"
                  />
                </div>
                <CardTitle className="text-base md:text-lg text-foreground line-clamp-2 min-h-[2.5rem]">
                  {product.name}
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-2">
                <span className="inline-block px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded">
                  {product.category}
                </span>
              </CardContent>
              <CardFooter className="flex flex-col gap-2 p-4 pt-2">
                <div className="w-full flex justify-between items-center">
                  <span className="text-xl md:text-2xl font-bold text-primary">{product.price}</span>
                </div>
                <Button className="w-full bg-accent hover:bg-accent/90 shadow-glow text-slate-800">
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Ajouter
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg">Aucun produit dans cette catégorie</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Accessoires;
