import { useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CalendarIcon, Upload, X, CheckCircle } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const Reservation = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const garageName = searchParams.get("garage") || "ce garage";
  const garageCity = searchParams.get("city") || "";
  
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    city: garageCity,
    service: "",
    date: undefined as Date | undefined,
    time: "",
    description: "",
  });
  
  const [file, setFile] = useState<File | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const services = [
    "Mécanique générale",
    "Lavage auto",
    "Peinture",
    "Vidange",
    "Constatation",
    "Diagnostic",
    "Carrosserie",
    "Climatisation",
    "Freinage",
    "Électricité auto",
    "Révision complète",
    "Géométrie",
    "Pneus",
    "Autre",
  ];

  const timeSlots = [
    "08:00", "09:00", "10:00", "11:00", "12:00",
    "14:00", "15:00", "16:00", "17:00", "18:00"
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      // Validate file size (20MB max)
      if (selectedFile.size > 20 * 1024 * 1024) {
        toast.error("Le fichier est trop volumineux. Taille maximale : 20 Mo");
        return;
      }
      
      // Validate file type
      const validTypes = ["image/jpeg", "image/png", "video/mp4", "video/quicktime"];
      if (!validTypes.includes(selectedFile.type)) {
        toast.error("Format non supporté. Formats acceptés : JPG, PNG, MP4, MOV");
        return;
      }
      
      setFile(selectedFile);
    }
  };

  const handleRemoveFile = () => {
    setFile(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.name || !formData.phone || !formData.service || !formData.date || !formData.time) {
      toast.error("Veuillez remplir tous les champs obligatoires");
      return;
    }

    // Simulate form submission
    console.log("Reservation data:", formData, file);
    setIsSubmitted(true);
    toast.success("Votre demande a été envoyée avec succès !");
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen py-12 flex items-center justify-center">
        <Card className="max-w-md w-full mx-4 shadow-elegant">
          <CardHeader className="text-center">
            <CheckCircle className="h-16 w-16 text-accent mx-auto mb-4" />
            <CardTitle className="text-2xl text-primary">Demande envoyée !</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-muted-foreground">
              Merci pour votre demande de réservation chez <span className="font-semibold text-foreground">{garageName}</span>.
            </p>
            <p className="text-muted-foreground">
              Un conseiller Vro vous contactera très prochainement au <span className="font-semibold text-foreground">{formData.phone}</span> pour confirmer votre rendez-vous.
            </p>
            <div className="pt-4 space-y-2">
              <Button onClick={() => navigate("/garagistes")} className="w-full">
                Retour aux garages
              </Button>
              <Button variant="outline" onClick={() => navigate("/")} className="w-full">
                Retour à l'accueil
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-3 text-gradient-silver">
            Réserver un service chez {garageName}
          </h1>
          <p className="text-muted-foreground">
            Remplissez les informations ci-dessous pour confirmer votre demande. Un conseiller Vro vous contactera sous peu.
          </p>
        </div>

        {/* Form */}
        <Card className="shadow-elegant">
          <CardContent className="pt-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Nom complet */}
              <div className="space-y-2">
                <Label htmlFor="name">Nom complet <span className="text-destructive">*</span></Label>
                <Input
                  id="name"
                  placeholder="Votre nom complet"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              {/* Téléphone */}
              <div className="space-y-2">
                <Label htmlFor="phone">Numéro de téléphone / WhatsApp <span className="text-destructive">*</span></Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="+212 6XX-XXXXXX"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  required
                />
              </div>

              {/* Ville */}
              <div className="space-y-2">
                <Label htmlFor="city">Ville</Label>
                <Input
                  id="city"
                  placeholder="Votre ville"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                />
              </div>

              {/* Type de service */}
              <div className="space-y-2">
                <Label htmlFor="service">Type de service souhaité <span className="text-destructive">*</span></Label>
                <Select value={formData.service} onValueChange={(value) => setFormData({ ...formData, service: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionnez un service" />
                  </SelectTrigger>
                  <SelectContent>
                    {services.map((service) => (
                      <SelectItem key={service} value={service}>
                        {service}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Date et heure */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Date souhaitée <span className="text-destructive">*</span></Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !formData.date && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.date ? format(formData.date, "PPP", { locale: fr }) : "Choisir une date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={formData.date}
                        onSelect={(date) => setFormData({ ...formData, date })}
                        disabled={(date) => date < new Date()}
                        initialFocus
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="time">Heure souhaitée <span className="text-destructive">*</span></Label>
                  <Select value={formData.time} onValueChange={(value) => setFormData({ ...formData, time: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choisir l'heure" />
                    </SelectTrigger>
                    <SelectContent>
                      {timeSlots.map((time) => (
                        <SelectItem key={time} value={time}>
                          {time}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <Label htmlFor="description">Description du problème</Label>
                <Textarea
                  id="description"
                  placeholder="Décrivez le problème ou le service dont vous avez besoin (max 300 caractères)"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value.slice(0, 300) })}
                  maxLength={300}
                  rows={4}
                />
                <p className="text-xs text-muted-foreground text-right">
                  {formData.description.length}/300
                </p>
              </div>

              {/* File upload */}
              <div className="space-y-2">
                <Label htmlFor="file">Pièce jointe (optionnel)</Label>
                <div className="space-y-2">
                  {!file ? (
                    <div>
                      <label htmlFor="file-upload" className="cursor-pointer">
                        <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary transition-smooth">
                          <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                          <p className="text-sm text-muted-foreground">
                            Joindre une photo ou une vidéo
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            JPG, PNG, MP4, MOV (max 20 Mo)
                          </p>
                        </div>
                      </label>
                      <input
                        id="file-upload"
                        type="file"
                        className="hidden"
                        accept="image/jpeg,image/png,video/mp4,video/quicktime"
                        onChange={handleFileChange}
                      />
                    </div>
                  ) : (
                    <div className="border border-border rounded-lg p-4 flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        {file.type.startsWith("image/") ? (
                          <img
                            src={URL.createObjectURL(file)}
                            alt="Preview"
                            className="h-12 w-12 object-cover rounded"
                          />
                        ) : (
                          <div className="h-12 w-12 bg-secondary rounded flex items-center justify-center">
                            <Upload className="h-6 w-6 text-muted-foreground" />
                          </div>
                        )}
                        <div>
                          <p className="text-sm font-medium">{file.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {(file.size / 1024 / 1024).toFixed(2)} Mo
                          </p>
                        </div>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={handleRemoveFile}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>
              </div>

              {/* Submit button */}
              <div className="pt-4">
                <Button type="submit" className="w-full bg-accent hover:bg-accent/90 shadow-glow text-lg py-6">
                  Envoyer ma demande
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Reservation;
