import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Star, TrendingUp, Award, Eye, MousePointer } from "lucide-react";
import { useNavigate } from "react-router-dom";

const ServicesPremium = () => {
  const navigate = useNavigate();

  const packs = [
    {
      name: "Bronze",
      price: "299",
      color: "bg-amber-700",
      icon: Award,
      features: [
        "Mise en avant basique dans les recherches",
        "Apparition dans les résultats prioritaires",
        "Badge Bronze sur votre profil",
        "Support par email"
      ],
      popular: false
    },
    {
      name: "Silver",
      price: "599",
      color: "bg-slate-400",
      icon: Star,
      features: [
        "Tous les avantages Bronze",
        "Badge \"Garage Recommandé\"",
        "Affichage prioritaire sur la carte",
        "Position privilégiée dans les listes",
        "Support prioritaire par téléphone"
      ],
      popular: true
    },
    {
      name: "Gold",
      price: "999",
      color: "bg-yellow-500",
      icon: TrendingUp,
      features: [
        "Tous les avantages Silver",
        "Bannière publicitaire sur la page d'accueil",
        "Mise en avant maximale sur la carte",
        "Accès au tableau de bord statistiques",
        "Suivi des clics et des vues",
        "Rapports mensuels détaillés",
        "Support VIP 24/7"
      ],
      popular: false
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <Badge className="mb-4" variant="secondary">
            Services Premium
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Boostez la Visibilité de Votre Garage
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            Choisissez le pack publicitaire adapté à vos besoins et attirez plus de clients
          </p>
        </div>
      </section>

      {/* Packs Section */}
      <section className="py-12 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {packs.map((pack) => {
              const IconComponent = pack.icon;
              return (
                <Card 
                  key={pack.name} 
                  className={`relative ${pack.popular ? 'border-primary border-2 shadow-lg scale-105' : ''}`}
                >
                  {pack.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                      <Badge className="bg-primary text-primary-foreground px-4 py-1">
                        Plus Populaire
                      </Badge>
                    </div>
                  )}
                  
                  <CardHeader className="text-center pb-4">
                    <div className={`w-16 h-16 ${pack.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                      <IconComponent className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-2xl">{pack.name}</CardTitle>
                    <CardDescription className="mt-2">
                      <span className="text-4xl font-bold text-foreground">{pack.price}</span>
                      <span className="text-muted-foreground"> MAD/mois</span>
                    </CardDescription>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    <ul className="space-y-3">
                      {pack.features.map((feature, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>

                  <CardFooter>
                    <Button 
                      className="w-full" 
                      variant={pack.popular ? "default" : "outline"}
                      onClick={() => navigate('/inscription-garage')}
                    >
                      Choisir {pack.name}
                    </Button>
                  </CardFooter>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Dashboard Preview for Gold */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">
              Tableau de Bord Statistiques (Pack Gold)
            </h2>
            <p className="text-muted-foreground">
              Suivez vos performances en temps réel avec des statistiques détaillées
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Eye className="w-4 h-4 text-primary" />
                  Vues du Profil
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">2,547</div>
                <p className="text-xs text-muted-foreground mt-1">
                  +12% ce mois-ci
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <MousePointer className="w-4 h-4 text-primary" />
                  Clics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">892</div>
                <p className="text-xs text-muted-foreground mt-1">
                  +8% ce mois-ci
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-primary" />
                  Taux de Conversion
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">35%</div>
                <p className="text-xs text-muted-foreground mt-1">
                  +5% ce mois-ci
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto text-center max-w-2xl">
          <h2 className="text-3xl font-bold mb-4">
            Prêt à Développer Votre Activité ?
          </h2>
          <p className="text-muted-foreground mb-8">
            Rejoignez des centaines de garages qui ont déjà boosté leur visibilité avec nos packs premium
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Button size="lg" onClick={() => navigate('/inscription-garage')}>
              Commencer Maintenant
            </Button>
            <Button size="lg" variant="outline" onClick={() => navigate('/contact')}>
              Nous Contacter
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ServicesPremium;
