import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { useMarketplaceAuth } from '@/contexts/MarketplaceAuthContext';
import { marketplaceOffers, serviceTypes, cities, MarketplaceOffer } from '@/data/marketplaceOffers';
import { Search, LogOut, Grid3x3, List, Calendar, MapPin, Paperclip, TrendingUp, FileText, Download, LayoutGrid } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

const Marketplace = () => {
  const { isAuthenticated, logout } = useMarketplaceAuth();
  const navigate = useNavigate();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCity, setSelectedCity] = useState('Toutes');
  const [selectedService, setSelectedService] = useState('Tous');
  const [budgetRange, setBudgetRange] = useState([0, 10000]);
  const [filteredOffers, setFilteredOffers] = useState<MarketplaceOffer[]>(marketplaceOffers);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/marketplace-login');
    }
  }, [isAuthenticated, navigate]);

  useEffect(() => {
    let filtered = marketplaceOffers;

    if (searchQuery) {
      filtered = filtered.filter(offer =>
        offer.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        offer.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedCity !== 'Toutes') {
      filtered = filtered.filter(offer => offer.city === selectedCity);
    }

    if (selectedService !== 'Tous') {
      filtered = filtered.filter(offer => offer.serviceType === selectedService);
    }

    filtered = filtered.filter(offer =>
      offer.budgetMin <= budgetRange[1] && offer.budgetMax >= budgetRange[0]
    );

    setFilteredOffers(filtered);
  }, [searchQuery, selectedCity, selectedService, budgetRange]);

  const handleLogout = () => {
    logout();
    navigate('/marketplace-login');
  };

  const handleExportCSV = () => {
    const headers = ['ID', 'Titre', 'Type', 'Ville', 'Budget Min', 'Budget Max', 'Date', 'Statut', 'Email Client'];
    const rows = marketplaceOffers.map(offer => [
      offer.id,
      offer.title,
      offer.serviceType,
      offer.city,
      offer.budgetMin,
      offer.budgetMax,
      offer.date,
      offer.status,
      offer.clientEmail
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'marketplace-offers.csv';
    a.click();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ouverte': return 'bg-green-500/10 text-green-600 border-green-500/20';
      case 'réservée': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
      case 'fermée': return 'bg-slate-500/10 text-slate-600 border-slate-500/20';
      default: return '';
    }
  };

  const openOffers = filteredOffers.filter(o => o.status === 'ouverte').length;
  const newOffers24h = filteredOffers.filter(o => {
    const offerDate = new Date(o.date);
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    return offerDate >= yesterday;
  }).length;

  if (!isAuthenticated) return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">Marketplace – Vro Garage</h1>
              <p className="text-sm text-muted-foreground">Espace Premium — accès réservé aux garagistes premium</p>
            </div>
            <div className="flex items-center gap-3">
              <Link to="/marketplace-dashboard">
                <Button variant="outline">
                  <LayoutGrid className="w-4 h-4 mr-2" />
                  Mon tableau de bord
                </Button>
              </Link>
              <Button variant="outline" onClick={handleExportCSV}>
                <Download className="w-4 h-4 mr-2" />
                Exporter CSV
              </Button>
              <Button variant="outline" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Se déconnecter
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Warning Alert */}
        <Alert className="mb-6 border-amber-500/50 bg-amber-500/10">
          <AlertDescription className="text-sm text-amber-600 dark:text-amber-400">
            ⚠️ <strong>Environnement de prototype</strong> - Identifiants temporaires actifs. À remplacer en production.
          </AlertDescription>
        </Alert>

        {/* Analytics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Offres disponibles</p>
                  <p className="text-3xl font-bold">{openOffers}</p>
                </div>
                <FileText className="w-8 h-8 text-primary/60" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Nouvelles (24h)</p>
                  <p className="text-3xl font-bold">{newOffers24h}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-500/60" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total offres</p>
                  <p className="text-3xl font-bold">{marketplaceOffers.length}</p>
                </div>
                <FileText className="w-8 h-8 text-blue-500/60" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">Filtres & Recherche</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Rechercher par titre ou description..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Ville</label>
                <Select value={selectedCity} onValueChange={setSelectedCity}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {cities.map(city => (
                      <SelectItem key={city} value={city}>{city}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Type de service</label>
                <Select value={selectedService} onValueChange={setSelectedService}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {serviceTypes.map(type => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">
                  Budget: {budgetRange[0]} - {budgetRange[1]} DH
                </label>
                <Slider
                  min={0}
                  max={10000}
                  step={100}
                  value={budgetRange}
                  onValueChange={setBudgetRange}
                  className="mt-2"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* View Toggle */}
        <div className="flex items-center justify-between mb-6">
          <p className="text-sm text-muted-foreground">
            {filteredOffers.length} offre{filteredOffers.length > 1 ? 's' : ''} trouvée{filteredOffers.length > 1 ? 's' : ''}
          </p>
          <div className="flex gap-2">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('grid')}
            >
              <Grid3x3 className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('list')}
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Offers Grid/List */}
        <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' : 'space-y-4'}>
          {filteredOffers.map(offer => (
            <Card key={offer.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <CardTitle className="text-lg line-clamp-1">{offer.title}</CardTitle>
                    <CardDescription className="text-xs mt-1">
                      Réf: {offer.id}
                    </CardDescription>
                  </div>
                  <Badge className={getStatusColor(offer.status)} variant="outline">
                    {offer.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="aspect-video rounded-lg overflow-hidden bg-muted">
                  <img src={offer.images[0]} alt={offer.title} className="w-full h-full object-cover" />
                </div>

                <p className="text-sm text-muted-foreground line-clamp-2">{offer.description}</p>

                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-xs">{offer.serviceType}</Badge>
                    <div className="flex items-center text-muted-foreground">
                      <MapPin className="w-3 h-3 mr-1" />
                      {offer.city}
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(offer.date).toLocaleDateString('fr-FR')}
                    </div>
                    {offer.attachments > 0 && (
                      <div className="flex items-center gap-1">
                        <Paperclip className="w-3 h-3" />
                        {offer.attachments} fichier{offer.attachments > 1 ? 's' : ''}
                      </div>
                    )}
                  </div>

                  <div className="pt-2 border-t">
                    <p className="text-xs text-muted-foreground mb-1">Budget indicatif</p>
                    <p className="font-semibold text-primary">
                      {offer.budgetMin.toLocaleString()} - {offer.budgetMax.toLocaleString()} DH
                    </p>
                  </div>
                </div>

                <Link to={`/marketplace/offer/${offer.id}`}>
                  <Button className="w-full" disabled={offer.status === 'fermée'}>
                    Voir détails & postuler
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredOffers.length === 0 && (
          <Card className="p-12">
            <div className="text-center text-muted-foreground">
              <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Aucune offre ne correspond à vos critères de recherche</p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Marketplace;
